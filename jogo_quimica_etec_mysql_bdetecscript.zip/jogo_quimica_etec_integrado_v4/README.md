# Jogo Química ETEC - MySQL

Este projeto foi ajustado para usar o banco MySQL `bdetecscript`.

## Como executar

1. Inicie o MySQL pelo XAMPP/WAMP ou servidor local.
2. Instale as dependências:

```bash
pip install -r requirements.txt
```

3. Execute o sistema:

```bash
python main.py
```

Por padrão, o sistema conecta em:

- host: `localhost`
- porta: `3306`
- usuário: `root`
- senha: vazia
- banco: `bdetecscript`

Caso seu MySQL tenha senha ou outro usuário, configure variáveis de ambiente antes de executar:

```bash
set MYSQL_USER=root
set MYSQL_PASSWORD=sua_senha
set MYSQL_DATABASE=bdetecscript
python main.py
```

O próprio programa cria o banco e as tabelas automaticamente se ainda não existirem.

## Logins de teste

Aluno: `aluno.demo@aluno.cps.sp.gov.br` / senha: `123456`

Professor: `professor.demo@cps.sp.gov.br` / senha: `123456`
