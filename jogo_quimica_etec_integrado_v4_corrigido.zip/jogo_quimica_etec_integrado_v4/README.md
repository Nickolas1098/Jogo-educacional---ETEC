# Jogo Química ETEC - Versão corrigida

Esta versão foi corrigida a partir do código integrado v4.

Correções:
- As alternativas agora usam ilustrações de materiais de laboratório, não apenas texto pequeno.
- O layout da tela de perguntas foi ampliado.
- As imagens das alternativas ficaram maiores.
- O sistema mantém o banco SQLite integrado ao código.

## Como executar

Abra o terminal dentro da pasta do projeto e rode:

```bash
pip install pillow
python main.py
```

Usuários:
- aluno@etec.com / 123456
- professor@etec.com / 123456

Importante: use esta pasta nova extraída para não reaproveitar banco antigo de versões anteriores.
