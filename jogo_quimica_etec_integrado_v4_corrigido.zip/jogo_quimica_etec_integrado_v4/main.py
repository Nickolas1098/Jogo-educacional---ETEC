import tkinter as tk
from tkinter import ttk, filedialog
import sqlite3
from pathlib import Path
from datetime import datetime
import hashlib
import shutil

try:
    from PIL import Image, ImageTk, ImageDraw, ImageFont
except ImportError:
    raise SystemExit("Instale a biblioteca Pillow antes de executar: pip install pillow")

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "laboratorio_game.db"
IMG_DIR = APP_DIR / "imagens_materiais"
IMG_DIR.mkdir(exist_ok=True)

COR_VERMELHO = "#941611"
COR_VERMELHO_ESCURO = "#6F0F0C"
COR_CINZA = "#4A555C"
COR_FUNDO = "#F4F6F8"
COR_BRANCO = "#FFFFFF"
COR_BORDA = "#DDDDDD"
COR_VERDE = "#2E7D32"
COR_VERDE_CLARO = "#E8F5E9"
COR_ERRO = "#C62828"
COR_ERRO_CLARO = "#FFEBEE"
COR_DESTAQUE = "#F7F1F1"


def hash_senha(senha: str) -> str:
    return hashlib.sha256(senha.encode("utf-8")).hexdigest()


def conectar():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn



def fonte_padrao(tamanho=20, negrito=False):
    opcoes = [
        "arialbd.ttf" if negrito else "arial.ttf",
        "DejaVuSans-Bold.ttf" if negrito else "DejaVuSans.ttf"
    ]

    for nome in opcoes:
        try:
            return ImageFont.truetype(nome, tamanho)
        except Exception:
            pass

    return ImageFont.load_default()


def rotulo_material(draw, texto):
    fonte = fonte_padrao(28, True)
    bbox = draw.textbbox((0, 0), texto, font=fonte)
    largura = bbox[2] - bbox[0]
    draw.text(
        ((420 - largura) / 2, 258),
        texto,
        fill=COR_CINZA,
        font=fonte
    )


def criar_imagem_material(nome: str, arquivo: str) -> str:
    caminho = IMG_DIR / arquivo

    img = Image.new("RGB", (420, 300), "white")
    draw = ImageDraw.Draw(img)

    draw.rounded_rectangle(
        (10, 10, 410, 290),
        radius=22,
        fill="white",
        outline="#CFCFCF",
        width=3
    )

    azul_vidro = "#A8DFF0"
    azul_contorno = "#327C96"
    azul_liquido = "#74C0FC"
    verde_liquido = "#52B788"
    cinza = COR_CINZA
    vermelho = "#D62828"

    nome_base = nome.lower()

    if "béquer" in nome_base or "bequer" in nome_base:
        draw.line((135, 70, 160, 230), fill=azul_contorno, width=6)
        draw.line((285, 70, 260, 230), fill=azul_contorno, width=6)
        draw.line((160, 230, 260, 230), fill=azul_contorno, width=6)
        draw.ellipse((130, 50, 290, 90), outline=azul_contorno, width=6)
        draw.rectangle((160, 155, 260, 225), fill="#BDE0FE")
        draw.ellipse((160, 140, 260, 175), fill=azul_liquido, outline=azul_contorno, width=3)
        for y in [105, 130, 155, 180, 205]:
            draw.line((268, y, 288, y), fill=cinza, width=2)
        rotulo_material(draw, "Béquer")

    elif "funil" in nome_base:
        draw.polygon(
            [(105, 70), (315, 70), (240, 175), (180, 175)],
            outline=azul_contorno,
            fill="#E7F7FB"
        )
        draw.line((180, 175, 180, 235), fill=azul_contorno, width=6)
        draw.line((240, 175, 240, 235), fill=azul_contorno, width=6)
        draw.line((180, 235, 240, 235), fill=azul_contorno, width=6)
        draw.arc((105, 45, 315, 95), 0, 180, fill=azul_contorno, width=5)
        draw.polygon([(135, 90), (285, 90), (235, 150), (185, 150)], fill="#CDEFFD")
        rotulo_material(draw, "Funil analítico")

    elif "proveta" in nome_base:
        draw.rectangle((175, 65, 245, 230), outline=azul_contorno, width=6, fill="#E7F7FB")
        draw.ellipse((175, 45, 245, 85), outline=azul_contorno, width=6, fill="#F8FDFF")
        draw.rectangle((182, 155, 238, 225), fill="#BDE0FE")
        draw.ellipse((182, 140, 238, 170), fill=azul_liquido, outline=azul_contorno, width=2)
        draw.rectangle((135, 230, 285, 255), fill="#E0E0E0", outline=cinza, width=3)
        for y in range(95, 210, 22):
            draw.line((245, y, 270, y), fill=cinza, width=2)
        rotulo_material(draw, "Proveta")

    elif "pipeta" in nome_base:
        draw.line((100, 220, 315, 75), fill=azul_contorno, width=9)
        draw.line((112, 230, 327, 85), fill="#DDF7FF", width=5)
        draw.ellipse((192, 130, 255, 190), outline=azul_contorno, width=5, fill="#E7F7FB")
        draw.line((92, 225, 118, 244), fill=azul_contorno, width=5)
        draw.line((310, 70, 338, 55), fill=azul_contorno, width=5)
        rotulo_material(draw, "Pipeta")

    elif "cápsula" in nome_base or "capsula" in nome_base:
        draw.ellipse((105, 125, 315, 220), fill="#F7F7F7", outline=cinza, width=5)
        draw.arc((105, 95, 315, 200), 0, 180, fill=cinza, width=5)
        draw.ellipse((135, 140, 285, 195), fill="#FFFFFF", outline="#BDBDBD", width=2)
        draw.polygon([(300, 160), (365, 135), (322, 190)], fill="#F7F7F7", outline=cinza)
        rotulo_material(draw, "Cápsula")

    elif "termômetro" in nome_base or "termometro" in nome_base:
        draw.rounded_rectangle((190, 55, 230, 215), radius=18, fill="#F7F7F7", outline=cinza, width=4)
        draw.ellipse((170, 195, 250, 275), fill=vermelho, outline=cinza, width=4)
        draw.rectangle((202, 90, 218, 230), fill=vermelho)
        for y in range(80, 190, 22):
            draw.line((230, y, 255, y), fill=cinza, width=2)
        rotulo_material(draw, "Termômetro")

    elif "tripé" in nome_base or "tripe" in nome_base:
        draw.ellipse((120, 90, 300, 130), outline=cinza, width=6)
        draw.line((145, 125, 105, 240), fill=cinza, width=6)
        draw.line((210, 130, 210, 250), fill=cinza, width=6)
        draw.line((275, 125, 315, 240), fill=cinza, width=6)
        draw.line((90, 240, 125, 240), fill=cinza, width=5)
        draw.line((195, 250, 225, 250), fill=cinza, width=5)
        draw.line((300, 240, 335, 240), fill=cinza, width=5)
        rotulo_material(draw, "Tripé")

    elif "almofariz" in nome_base:
        draw.ellipse((110, 125, 310, 205), fill="#EEEEEE", outline=cinza, width=5)
        draw.arc((110, 105, 310, 245), 0, 180, fill=cinza, width=5)
        draw.polygon([(120, 160), (300, 160), (270, 245), (150, 245)], fill="#F5F5F5", outline=cinza)
        draw.line((290, 70, 190, 175), fill=cinza, width=15)
        draw.ellipse((270, 55, 315, 90), fill="#DDDDDD", outline=cinza, width=3)
        rotulo_material(draw, "Almofariz")

    elif "destilação" in nome_base or "destilacao" in nome_base:
        draw.ellipse((110, 155, 210, 250), fill="#E7F7FB", outline=azul_contorno, width=5)
        draw.rectangle((145, 85, 175, 165), fill="#E7F7FB", outline=azul_contorno, width=5)
        draw.line((170, 110, 310, 110), fill=azul_contorno, width=8)
        draw.line((310, 110, 350, 160), fill=azul_contorno, width=8)
        draw.rectangle((250, 85, 340, 135), fill="#DDF7FF", outline=azul_contorno, width=4)
        draw.polygon([(110, 250), (210, 250), (170, 275), (150, 275)], fill=cinza)
        draw.rectangle((90, 275, 230, 285), fill=cinza)
        rotulo_material(draw, "Destilação")

    elif "filtração" in nome_base or "filtracao" in nome_base:
        draw.line((75, 50, 75, 240), fill=cinza, width=7)
        draw.rectangle((40, 240, 125, 255), fill="#D9D9D9", outline=cinza, width=3)
        draw.line((75, 105, 175, 105), fill=cinza, width=5)
        draw.rectangle((155, 92, 185, 118), fill="#F2C94C", outline=cinza, width=3)

        draw.polygon([(165, 110), (305, 110), (245, 205), (210, 205)], outline=azul_contorno, fill="#E7F7FB")
        draw.polygon([(190, 135), (280, 135), (245, 190), (210, 190)], outline=cinza, fill="#F5F5F5")
        draw.rectangle((210, 205, 245, 250), outline=azul_contorno, width=5, fill="#E7F7FB")

        draw.ellipse((150, 235, 310, 280), outline=azul_contorno, width=5, fill="#E7F7FB")
        draw.rectangle((155, 255, 305, 280), fill="#BDE0FE")
        draw.ellipse((155, 245, 305, 270), fill=azul_liquido, outline=azul_contorno, width=3)

        draw.polygon([(210, 45), (350, 80), (315, 140), (180, 100)], outline=azul_contorno, fill="#E7F7FB")
        draw.polygon([(220, 65), (330, 88), (305, 120), (195, 95)], fill=verde_liquido)
        draw.line((270, 135, 225, 170), fill="#2B2B2B", width=6)
        rotulo_material(draw, "Filtração simples")

    else:
        fonte = fonte_padrao(28, True)
        bbox = draw.textbbox((0, 0), nome, font=fonte)
        draw.text(
            ((420 - (bbox[2] - bbox[0])) / 2, 130),
            nome,
            fill=COR_CINZA,
            font=fonte
        )

    img.save(caminho)
    return str(caminho)


def iniciar_banco():
    conn = conectar()
    cur = conn.cursor()

    # Banco SQLite equivalente ao bdetecscript.sql enviado.
    cur.executescript("""
    CREATE TABLE IF NOT EXISTS turmas (
        id_turma INTEGER PRIMARY KEY AUTOINCREMENT,
        nome_turma TEXT NOT NULL,
        ano_letivo INTEGER NOT NULL,
        ativa INTEGER DEFAULT 1,
        data_criacao TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS usuarios (
        id_usuario INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        senha_hash TEXT NOT NULL,
        tipo_usuario TEXT NOT NULL CHECK(tipo_usuario IN ('aluno', 'professor')),
        id_turma INTEGER NULL,
        ativo INTEGER DEFAULT 1,
        data_criacao TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_turma) REFERENCES turmas(id_turma) ON DELETE SET NULL ON UPDATE CASCADE
    );

    CREATE TABLE IF NOT EXISTS modos_jogo (
        id_modo INTEGER PRIMARY KEY AUTOINCREMENT,
        nome_modo TEXT NOT NULL,
        descricao TEXT,
        nivel INTEGER NOT NULL,
        ativo INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS perguntas (
        id_pergunta INTEGER PRIMARY KEY AUTOINCREMENT,
        id_modo INTEGER NOT NULL,
        id_professor_criador INTEGER NULL,
        enunciado TEXT NOT NULL,
        imagem_url TEXT NULL,
        tipo_pergunta TEXT DEFAULT 'multipla_escolha' CHECK(tipo_pergunta IN ('identificacao', 'multipla_escolha', 'associacao')),
        resposta_correta_texto TEXT NULL,
        pontuacao INTEGER DEFAULT 10,
        ativa INTEGER DEFAULT 1,
        data_criacao TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_modo) REFERENCES modos_jogo(id_modo) ON DELETE RESTRICT ON UPDATE CASCADE,
        FOREIGN KEY (id_professor_criador) REFERENCES usuarios(id_usuario) ON DELETE SET NULL ON UPDATE CASCADE
    );

    CREATE TABLE IF NOT EXISTS alternativas (
        id_alternativa INTEGER PRIMARY KEY AUTOINCREMENT,
        id_pergunta INTEGER NOT NULL,
        texto TEXT NULL,
        imagem_url TEXT NULL,
        correta INTEGER DEFAULT 0,
        ordem INTEGER DEFAULT 1,
        FOREIGN KEY (id_pergunta) REFERENCES perguntas(id_pergunta) ON DELETE CASCADE ON UPDATE CASCADE
    );

    CREATE TABLE IF NOT EXISTS dicas (
        id_dica INTEGER PRIMARY KEY AUTOINCREMENT,
        id_pergunta INTEGER NOT NULL,
        texto_dica TEXT NOT NULL,
        FOREIGN KEY (id_pergunta) REFERENCES perguntas(id_pergunta) ON DELETE CASCADE ON UPDATE CASCADE
    );

    CREATE TABLE IF NOT EXISTS partidas (
        id_partida INTEGER PRIMARY KEY AUTOINCREMENT,
        id_aluno INTEGER NOT NULL,
        id_modo INTEGER NOT NULL,
        pontuacao_total INTEGER DEFAULT 0,
        quantidade_acertos INTEGER DEFAULT 0,
        quantidade_erros INTEGER DEFAULT 0,
        total_perguntas INTEGER DEFAULT 0,
        data_inicio TEXT DEFAULT CURRENT_TIMESTAMP,
        data_fim TEXT NULL,
        status_partida TEXT DEFAULT 'em_andamento' CHECK(status_partida IN ('em_andamento', 'finalizada', 'cancelada')),
        FOREIGN KEY (id_aluno) REFERENCES usuarios(id_usuario) ON DELETE RESTRICT ON UPDATE CASCADE,
        FOREIGN KEY (id_modo) REFERENCES modos_jogo(id_modo) ON DELETE RESTRICT ON UPDATE CASCADE
    );

    CREATE TABLE IF NOT EXISTS respostas_partida (
        id_resposta_partida INTEGER PRIMARY KEY AUTOINCREMENT,
        id_partida INTEGER NOT NULL,
        id_pergunta INTEGER NOT NULL,
        id_alternativa INTEGER NULL,
        resposta_texto TEXT NULL,
        correta INTEGER NOT NULL,
        pontos_obtidos INTEGER DEFAULT 0,
        data_resposta TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_partida) REFERENCES partidas(id_partida) ON DELETE CASCADE ON UPDATE CASCADE,
        FOREIGN KEY (id_pergunta) REFERENCES perguntas(id_pergunta) ON DELETE RESTRICT ON UPDATE CASCADE,
        FOREIGN KEY (id_alternativa) REFERENCES alternativas(id_alternativa) ON DELETE SET NULL ON UPDATE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ajudas_utilizadas (
        id_ajuda_utilizada INTEGER PRIMARY KEY AUTOINCREMENT,
        id_partida INTEGER NOT NULL,
        id_pergunta INTEGER NOT NULL,
        tipo_ajuda TEXT NOT NULL CHECK(tipo_ajuda IN ('dica', 'eliminar_alternativas')),
        data_uso TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_partida) REFERENCES partidas(id_partida) ON DELETE CASCADE ON UPDATE CASCADE,
        FOREIGN KEY (id_pergunta) REFERENCES perguntas(id_pergunta) ON DELETE RESTRICT ON UPDATE CASCADE
    );
    """)

    if cur.execute("SELECT COUNT(*) FROM turmas").fetchone()[0] == 0:
        cur.execute("INSERT INTO turmas (nome_turma, ano_letivo) VALUES (?, ?)", ("1º Química A", datetime.now().year))

    if cur.execute("SELECT COUNT(*) FROM modos_jogo").fetchone()[0] == 0:
        cur.executemany("INSERT INTO modos_jogo (nome_modo, descricao, nivel) VALUES (?, ?, ?)", [
            ("Fácil", "Identificação inicial de materiais", 1),
            ("Médio", "Função dos materiais", 2),
            ("Difícil", "Sistemas experimentais", 3),
        ])

    if cur.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0] == 0:
        cur.executemany("""
            INSERT INTO usuarios (nome, email, senha_hash, tipo_usuario, id_turma)
            VALUES (?, ?, ?, ?, ?)
        """, [
            ("Aluno Demo", "aluno@etec.com", hash_senha("123456"), "aluno", 1),
            ("Professor Demo", "professor@etec.com", hash_senha("123456"), "professor", None),
        ])

    if cur.execute("SELECT COUNT(*) FROM perguntas").fetchone()[0] == 0:
        img_bequer = criar_imagem_material("Béquer", "bequer.png")
        img_funil = criar_imagem_material("Funil", "funil.png")
        img_proveta = criar_imagem_material("Proveta", "proveta.png")
        img_capsula = criar_imagem_material("Cápsula", "capsula.png")
        img_destilacao = criar_imagem_material("Destilação", "destilacao.png")
        img_pipeta = criar_imagem_material("Pipeta", "pipeta.png")
        img_tripe = criar_imagem_material("Tripé", "tripe.png")
        img_termometro = criar_imagem_material("Termômetro", "termometro.png")
        img_almofariz = criar_imagem_material("Almofariz", "almofariz.png")
        img_filtro = criar_imagem_material("Filtração simples", "filtracao_simples.png")

        def inserir_pergunta(id_modo, enunciado, imagem, tipo, correta_texto, pontuacao, dica, alternativas):
            cur.execute("""
                INSERT INTO perguntas (id_modo, id_professor_criador, enunciado, imagem_url, tipo_pergunta, resposta_correta_texto, pontuacao)
                VALUES (?, 2, ?, ?, ?, ?, ?)
            """, (id_modo, enunciado, imagem, tipo, correta_texto, pontuacao))
            idp = cur.lastrowid
            for ordem, (texto, img, correta) in enumerate(alternativas, start=1):
                cur.execute("""
                    INSERT INTO alternativas (id_pergunta, texto, imagem_url, correta, ordem)
                    VALUES (?, ?, ?, ?, ?)
                """, (idp, texto, img, 1 if correta else 0, ordem))
            cur.execute("INSERT INTO dicas (id_pergunta, texto_dica) VALUES (?, ?)", (idp, dica))

        inserir_pergunta(
            1,
            "Observe a imagem das alternativas e escolha o material mais utilizado para medir volumes aproximados de líquidos.",
            "",
            "identificacao",
            "Béquer",
            10,
            "É uma vidraria cilíndrica comum em laboratório.",
            [("Béquer", img_bequer, True), ("Funil analítico", img_funil, False), ("Proveta", img_proveta, False), ("Pipeta", img_pipeta, False)]
        )
        inserir_pergunta(
            1,
            "Qual material é usado na filtração simples para apoiar o papel de filtro?",
            img_filtro,
            "multipla_escolha",
            "Funil analítico",
            10,
            "O material correto tem formato cônico.",
            [("Funil analítico", img_funil, True), ("Béquer", img_bequer, False), ("Cápsula de porcelana", img_capsula, False), ("Termômetro", img_termometro, False)]
        )
        inserir_pergunta(
            2,
            "Escolha a imagem do material que mede volume com mais precisão do que um béquer.",
            "",
            "identificacao",
            "Proveta",
            10,
            "Possui marcações graduadas em seu corpo.",
            [("Erlenmeyer/frasco", img_destilacao, False), ("Proveta", img_proveta, True), ("Tripé", img_tripe, False), ("Almofariz", img_almofariz, False)]
        )
        inserir_pergunta(
            2,
            "Qual imagem representa o material utilizado para secagem ou aquecimento de pequenas quantidades de sólidos?",
            "",
            "identificacao",
            "Cápsula de porcelana",
            10,
            "É feito de porcelana e suporta aquecimento.",
            [("Pipeta", img_pipeta, False), ("Funil", img_funil, False), ("Cápsula de porcelana", img_capsula, True), ("Termômetro", img_termometro, False)]
        )
        inserir_pergunta(
            3,
            "O sistema mostrado corresponde a qual processo experimental?",
            img_filtro,
            "multipla_escolha",
            "Filtração simples",
            10,
            "O líquido atravessa um papel de filtro apoiado em um funil.",
            [("Filtração a vácuo", img_funil, False), ("Cristalização", img_capsula, False), ("Filtração simples", img_filtro, True), ("Filtração por membrana", img_bequer, False)]
        )

    conn.commit()
    conn.close()


class BotaoAnimado(tk.Button):
    def __init__(self, master, texto, comando, cor=COR_VERMELHO, largura=None):
        super().__init__(master, text=texto, command=comando, bg=cor, fg="white",
                         activebackground=COR_VERMELHO_ESCURO, activeforeground="white",
                         relief="flat", bd=0, cursor="hand2", font=("Arial", 11, "bold"),
                         padx=18, pady=10, width=largura)
        self.cor = cor
        self.bind("<Enter>", lambda e: self.config(bg=COR_VERMELHO_ESCURO))
        self.bind("<Leave>", lambda e: self.config(bg=self.cor))


class JogoQuimica:
    def __init__(self, root):
        self.root = root
        self.root.title("Química Experimental - ETEC")
        self.root.geometry("1400x850")
        self.root.minsize(1200, 720)
        self.root.configure(bg=COR_FUNDO)
        self.usuario = None
        self.questoes = []
        self.indice = 0
        self.pontos = 0
        self.acertos = 0
        self.erros = 0
        self.partida_id = None
        self.resposta_id = None
        self.alternativa_widgets = {}
        self.imagens_tk = []
        self.configurar_estilo()
        self.tela_inicial()

    def configurar_estilo(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview", font=("Arial", 10), rowheight=28)
        style.configure("Treeview.Heading", font=("Arial", 10, "bold"), background=COR_CINZA, foreground="white")
        style.configure("TEntry", padding=6)
        style.configure("TCombobox", padding=6)

    def limpar(self):
        for widget in self.root.winfo_children():
            widget.destroy()
        self.imagens_tk = []

    def cabecalho(self, titulo):
        frame = tk.Frame(self.root, bg=COR_VERMELHO, height=78)
        frame.pack(fill="x")
        frame.pack_propagate(False)
        tk.Label(frame, text=titulo, bg=COR_VERMELHO, fg="white", font=("Arial", 21, "bold")).pack(side="left", padx=28)
        tk.Label(frame, text="Centro Paula Souza • ETEC Júlio de Mesquita", bg=COR_VERMELHO, fg="white", font=("Arial", 10, "bold")).pack(side="right", padx=28)

    def card(self, parent, padx=30, pady=25):
        return tk.Frame(parent, bg=COR_BRANCO, padx=padx, pady=pady, highlightbackground=COR_BORDA, highlightthickness=1)

    def mostrar_mensagem(self, titulo, texto, tipo="info", ao_fechar=None):
        janela = tk.Toplevel(self.root)
        janela.title(titulo)
        janela.geometry("460x245")
        janela.configure(bg=COR_BRANCO)
        janela.resizable(False, False)
        janela.grab_set()
        cor = COR_VERDE if tipo == "sucesso" else COR_ERRO if tipo == "erro" else COR_VERMELHO
        simbolo = "✓" if tipo == "sucesso" else "✕" if tipo == "erro" else "!"
        tk.Label(janela, text=simbolo, bg=COR_BRANCO, fg=cor, font=("Arial", 42, "bold")).pack(pady=(18, 4))
        tk.Label(janela, text=titulo, bg=COR_BRANCO, fg=cor, font=("Arial", 16, "bold")).pack()
        tk.Label(janela, text=texto, bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 11), wraplength=380, justify="center").pack(pady=12)
        def fechar():
            janela.destroy()
            if ao_fechar:
                ao_fechar()
        BotaoAnimado(janela, "OK", fechar, largura=14, cor=cor).pack(pady=5)

    def carregar_imagem(self, caminho, tamanho=(260, 170)):
        if not caminho:
            return None
        try:
            img = Image.open(caminho)
            img = img.convert("RGB")
            img.thumbnail(tamanho, Image.LANCZOS)
            fundo = Image.new("RGB", tamanho, "white")
            x = (tamanho[0] - img.width) // 2
            y = (tamanho[1] - img.height) // 2
            fundo.paste(img, (x, y))
            foto = ImageTk.PhotoImage(fundo)
            self.imagens_tk.append(foto)
            return foto
        except Exception:
            return None

    def tela_inicial(self):
        self.limpar(); self.cabecalho("Química Experimental")
        conteudo = tk.Frame(self.root, bg=COR_FUNDO); conteudo.pack(expand=True, fill="both", padx=50, pady=35)
        tk.Label(conteudo, text="Jogo Educacional de Materiais de Laboratório", bg=COR_FUNDO, fg=COR_VERMELHO, font=("Arial", 28, "bold")).pack(pady=(20, 8))
        tk.Label(conteudo, text="Identifique materiais, funções e sistemas experimentais por meio de perguntas com imagens.", bg=COR_FUNDO, fg=COR_CINZA, font=("Arial", 14), wraplength=820, justify="center").pack(pady=8)
        card = self.card(conteudo, 40, 32); card.pack(pady=35)
        BotaoAnimado(card, "Entrar", self.tela_login, largura=30).pack(pady=8)
        BotaoAnimado(card, "Cadastrar usuário", self.tela_cadastro, largura=30, cor=COR_CINZA).pack(pady=8)
        BotaoAnimado(card, "Sair", self.root.destroy, largura=30, cor="#777777").pack(pady=8)
        tk.Label(conteudo, text="Aluno: aluno@etec.com / 123456  |  Professor: professor@etec.com / 123456", bg=COR_FUNDO, fg=COR_CINZA, font=("Arial", 10)).pack(pady=10)

    def campo(self, parent, texto, show=None):
        tk.Label(parent, text=texto, bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 11, "bold")).pack(anchor="w", pady=(8, 2))
        entrada = ttk.Entry(parent, show=show, width=44); entrada.pack(fill="x")
        return entrada

    def tela_login(self):
        self.limpar(); self.cabecalho("Acesso ao Sistema")
        card = self.card(self.root, 38, 32); card.pack(expand=True)
        tk.Label(card, text="Entrar na plataforma", bg=COR_BRANCO, fg=COR_VERMELHO, font=("Arial", 22, "bold")).pack(pady=(0, 10))
        email = self.campo(card, "E-mail"); senha = self.campo(card, "Senha", show="*")
        def entrar():
            conn = conectar()
            user = conn.execute("SELECT * FROM usuarios WHERE email=? AND ativo=1", (email.get().strip().lower(),)).fetchone()
            conn.close()
            if user and user["senha_hash"] == hash_senha(senha.get()):
                self.usuario = dict(user)
                self.tela_professor() if user["tipo_usuario"] == "professor" else self.tela_menu_aluno()
            else:
                self.mostrar_mensagem("Acesso negado", "E-mail ou senha inválidos.", "erro")
        BotaoAnimado(card, "Entrar", entrar, largura=30).pack(pady=(20, 8))
        BotaoAnimado(card, "Voltar", self.tela_inicial, largura=30, cor=COR_CINZA).pack(pady=6)

    def tela_cadastro(self):
        self.limpar(); self.cabecalho("Cadastro de Usuário")
        card = self.card(self.root, 35, 25); card.pack(pady=35)
        tk.Label(card, text="Criar novo usuário", bg=COR_BRANCO, fg=COR_VERMELHO, font=("Arial", 20, "bold")).pack(pady=8)
        nome = self.campo(card, "Nome"); email = self.campo(card, "E-mail"); senha = self.campo(card, "Senha", show="*")
        tk.Label(card, text="Tipo de usuário", bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 11, "bold")).pack(anchor="w", pady=(8, 2))
        tipo = ttk.Combobox(card, values=["aluno", "professor"], state="readonly"); tipo.set("aluno"); tipo.pack(fill="x")
        def cadastrar():
            if not nome.get() or not email.get() or not senha.get():
                self.mostrar_mensagem("Campos obrigatórios", "Preencha todos os campos antes de continuar.", "info"); return
            try:
                conn = conectar()
                id_turma = 1 if tipo.get() == "aluno" else None
                conn.execute("INSERT INTO usuarios (nome,email,senha_hash,tipo_usuario,id_turma) VALUES (?,?,?,?,?)", (nome.get(), email.get().strip().lower(), hash_senha(senha.get()), tipo.get(), id_turma))
                conn.commit(); conn.close()
                self.mostrar_mensagem("Cadastro realizado", "Usuário cadastrado com sucesso.", "sucesso", self.tela_login)
            except sqlite3.IntegrityError:
                self.mostrar_mensagem("E-mail já cadastrado", "Use outro e-mail para realizar o cadastro.", "erro")
        BotaoAnimado(card, "Cadastrar", cadastrar, largura=30).pack(pady=(18, 8))
        BotaoAnimado(card, "Voltar", self.tela_inicial, largura=30, cor=COR_CINZA).pack(pady=6)

    def tela_menu_aluno(self):
        self.limpar(); self.cabecalho("Área do Aluno")
        conteudo = tk.Frame(self.root, bg=COR_FUNDO); conteudo.pack(expand=True, fill="both", padx=45, pady=35)
        tk.Label(conteudo, text=f"Olá, {self.usuario['nome']}!", bg=COR_FUNDO, fg=COR_CINZA, font=("Arial", 19, "bold")).pack(pady=10)
        card = self.card(conteudo, 45, 32); card.pack(pady=30)
        BotaoAnimado(card, "Iniciar jogo", self.iniciar_jogo, largura=34).pack(pady=8)
        BotaoAnimado(card, "Ver ranking", self.tela_ranking, largura=34, cor=COR_CINZA).pack(pady=8)
        BotaoAnimado(card, "Sair", self.tela_inicial, largura=34, cor=COR_CINZA).pack(pady=8)

    def iniciar_jogo(self):
        conn = conectar()
        self.questoes = conn.execute("SELECT * FROM perguntas WHERE ativa=1 ORDER BY id_modo, id_pergunta").fetchall()
        if not self.questoes:
            conn.close(); self.mostrar_mensagem("Sem perguntas", "Nenhuma pergunta cadastrada.", "info"); return
        conn.execute("INSERT INTO partidas (id_aluno,id_modo,total_perguntas) VALUES (?,?,?)", (self.usuario["id_usuario"], self.questoes[0]["id_modo"], len(self.questoes)))
        self.partida_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.commit(); conn.close()
        self.indice = 0; self.pontos = 0; self.acertos = 0; self.erros = 0; self.resposta_id = None
        self.tela_questao()

    def selecionar_alternativa(self, id_alt):
        self.resposta_id = id_alt
        for aid, widget in self.alternativa_widgets.items():
            widget.config(bg=COR_DESTAQUE if aid == id_alt else COR_BRANCO, highlightbackground=COR_VERMELHO if aid == id_alt else COR_BORDA, highlightthickness=2 if aid == id_alt else 1)

    def tela_questao(self):
        self.limpar(); self.cabecalho("Jogo - Materiais de Laboratório")
        if self.indice >= len(self.questoes):
            self.finalizar_jogo(); return
        q = self.questoes[self.indice]
        self.resposta_id = None; self.alternativa_widgets = {}
        conn = conectar()
        alternativas = conn.execute("SELECT * FROM alternativas WHERE id_pergunta=? ORDER BY ordem", (q["id_pergunta"],)).fetchall()
        dica = conn.execute("SELECT texto_dica FROM dicas WHERE id_pergunta=? LIMIT 1", (q["id_pergunta"],)).fetchone()
        conn.close()
        conteudo = tk.Frame(self.root, bg=COR_FUNDO); conteudo.pack(expand=True, fill="both", padx=35, pady=24)
        tk.Label(conteudo, text=f"Questão {self.indice+1}/{len(self.questoes)}   •   Pontos: {self.pontos}   •   Valor: {q['pontuacao']} pontos", bg=COR_FUNDO, fg=COR_CINZA, font=("Arial", 12, "bold")).pack(anchor="w", pady=(0, 12))
        card = self.card(conteudo, 30, 22); card.pack(fill="both", expand=True)
        tk.Label(card, text=q["enunciado"], bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 19, "bold"), wraplength=1220, justify="left").pack(anchor="w", pady=(0, 20))
        area = tk.Frame(card, bg=COR_BRANCO); area.pack(fill="both", expand=True)
        frame_img = tk.Frame(area, bg=COR_BRANCO, width=390); frame_img.pack(side="left", fill="y", padx=(0, 28), anchor="n")
        frame_alt = tk.Frame(area, bg=COR_BRANCO); frame_alt.pack(side="right", fill="both", expand=True)
        foto_pergunta = self.carregar_imagem(q["imagem_url"], (360, 280))
        if foto_pergunta:
            tk.Label(frame_img, image=foto_pergunta, bg=COR_BRANCO, highlightbackground=COR_BORDA, highlightthickness=1).pack(pady=8)
        else:
            tk.Label(frame_img, text="Escolha a alternativa\ncorreta pelas imagens", bg="#F1F1F1", fg=COR_CINZA, font=("Arial", 13, "bold"), width=32, height=10).pack(pady=8)
        for alt in alternativas:
            caixa = tk.Frame(frame_alt, bg=COR_BRANCO, padx=12, pady=10, highlightbackground=COR_BORDA, highlightthickness=1, cursor="hand2")
            caixa.pack(fill="x", pady=6)
            tk.Label(caixa, text=chr(64+alt["ordem"]), bg=COR_VERMELHO, fg="white", font=("Arial", 12, "bold"), width=3).pack(side="left", padx=(0, 10))
            foto_alt = self.carregar_imagem(alt["imagem_url"], (180, 120))
            if foto_alt:
                tk.Label(caixa, image=foto_alt, bg=COR_BRANCO).pack(side="left", padx=(0, 12))
            tk.Label(caixa, text=alt["texto"] or "", bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 15, "bold"), anchor="w").pack(side="left", fill="x", expand=True)
            caixa.bind("<Button-1>", lambda e, aid=alt["id_alternativa"]: self.selecionar_alternativa(aid))
            for child in caixa.winfo_children():
                child.bind("<Button-1>", lambda e, aid=alt["id_alternativa"]: self.selecionar_alternativa(aid))
            self.alternativa_widgets[alt["id_alternativa"]] = caixa
        botoes = tk.Frame(card, bg=COR_BRANCO); botoes.pack(fill="x", pady=30)
        def usar_dica():
            if self.partida_id:
                conn = conectar(); conn.execute("INSERT INTO ajudas_utilizadas (id_partida,id_pergunta,tipo_ajuda) VALUES (?,?,?)", (self.partida_id, q["id_pergunta"], "dica")); conn.commit(); conn.close()
            self.mostrar_mensagem("Dica", dica["texto_dica"] if dica else "Sem dica cadastrada.", "info")
        BotaoAnimado(botoes, "Dica", usar_dica, cor=COR_CINZA).pack(side="left", padx=5)
        BotaoAnimado(botoes, "Responder", self.verificar_resposta).pack(side="right", padx=5)
        BotaoAnimado(botoes, "Sair", self.tela_menu_aluno, cor=COR_CINZA).pack(side="right", padx=5)

    def verificar_resposta(self):
        if not self.resposta_id:
            self.mostrar_mensagem("Selecione uma alternativa", "Clique em uma das alternativas antes de responder.", "info"); return
        q = self.questoes[self.indice]
        conn = conectar()
        alt = conn.execute("SELECT * FROM alternativas WHERE id_alternativa=?", (self.resposta_id,)).fetchone()
        correta_alt = conn.execute("SELECT * FROM alternativas WHERE id_pergunta=? AND correta=1 LIMIT 1", (q["id_pergunta"],)).fetchone()
        correta = bool(alt["correta"])
        pontos = q["pontuacao"] if correta else 0
        conn.execute("INSERT INTO respostas_partida (id_partida,id_pergunta,id_alternativa,resposta_texto,correta,pontos_obtidos) VALUES (?,?,?,?,?,?)", (self.partida_id, q["id_pergunta"], self.resposta_id, alt["texto"], 1 if correta else 0, pontos))
        conn.commit(); conn.close()
        for aid, widget in self.alternativa_widgets.items():
            if correta_alt and aid == correta_alt["id_alternativa"]:
                widget.config(bg=COR_VERDE_CLARO, highlightbackground=COR_VERDE, highlightthickness=3)
            elif aid == self.resposta_id:
                widget.config(bg=COR_ERRO_CLARO, highlightbackground=COR_ERRO, highlightthickness=3)
        if correta:
            self.pontos += pontos; self.acertos += 1
            self.root.after(700, lambda: self.mostrar_mensagem("Resposta correta", "Muito bem! Você acertou a questão.", "sucesso", self.proxima_questao))
        else:
            self.erros += 1
            texto = f"A alternativa correta era: {correta_alt['texto']}" if correta_alt else "A resposta estava incorreta."
            self.root.after(700, lambda: self.mostrar_mensagem("Resposta incorreta", texto, "erro", self.proxima_questao))

    def proxima_questao(self):
        self.indice += 1
        self.tela_questao()

    def finalizar_jogo(self):
        conn = conectar()
        conn.execute("""
            UPDATE partidas SET pontuacao_total=?, quantidade_acertos=?, quantidade_erros=?, total_perguntas=?, data_fim=?, status_partida='finalizada'
            WHERE id_partida=?
        """, (self.pontos, self.acertos, self.erros, len(self.questoes), datetime.now().strftime("%Y-%m-%d %H:%M:%S"), self.partida_id))
        conn.commit(); conn.close()
        total = len(self.questoes); percentual = round((self.acertos/total)*100, 1) if total else 0
        self.limpar(); self.cabecalho("Resultado")
        card = self.card(self.root, 45, 35); card.pack(pady=80)
        tk.Label(card, text="Partida finalizada!", bg=COR_BRANCO, fg=COR_VERMELHO, font=("Arial", 25, "bold")).pack(pady=10)
        tk.Label(card, text=f"Pontuação: {self.pontos} pontos", bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 18)).pack(pady=8)
        tk.Label(card, text=f"Acertos: {self.acertos}/{total}  •  Aproveitamento: {percentual}%", bg=COR_BRANCO, fg=COR_VERDE, font=("Arial", 16, "bold")).pack(pady=8)
        BotaoAnimado(card, "Jogar novamente", self.iniciar_jogo, largura=30).pack(pady=8)
        BotaoAnimado(card, "Ver ranking", self.tela_ranking, largura=30, cor=COR_CINZA).pack(pady=8)
        BotaoAnimado(card, "Voltar ao menu", self.tela_menu_aluno, largura=30, cor=COR_CINZA).pack(pady=8)

    def tela_professor(self):
        self.limpar(); self.cabecalho("Área do Professor")
        conteudo = tk.Frame(self.root, bg=COR_FUNDO); conteudo.pack(expand=True, fill="both", padx=45, pady=35)
        tk.Label(conteudo, text=f"Bem-vindo(a), {self.usuario['nome']}", bg=COR_FUNDO, fg=COR_CINZA, font=("Arial", 18, "bold")).pack(anchor="w", pady=10)
        card = self.card(conteudo, 40, 28); card.pack(fill="x", pady=15)
        for texto, cmd in [("Cadastrar nova pergunta", self.tela_nova_questao), ("Visualizar perguntas", self.tela_listar_questoes), ("Visualizar usuários", self.tela_usuarios), ("Relatórios", self.tela_relatorios), ("Ranking geral", self.tela_ranking)]:
            BotaoAnimado(card, texto, cmd, largura=38, cor=COR_CINZA if texto != "Cadastrar nova pergunta" else COR_VERMELHO).pack(pady=8)
        BotaoAnimado(card, "Sair", self.tela_inicial, largura=38, cor="#777777").pack(pady=8)

    def tela_nova_questao(self):
        self.limpar(); self.cabecalho("Cadastrar Pergunta")
        frame = self.card(self.root, 28, 14); frame.pack(fill="both", expand=True, padx=35, pady=20)
        def label(t): tk.Label(frame, text=t, bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 10, "bold")).pack(anchor="w", pady=(4,1))
        label("Enunciado")
        enunciado = tk.Text(frame, height=3, font=("Arial", 10)); enunciado.pack(fill="x")
        caminho_pergunta = tk.StringVar(value="")
        def escolher_pergunta(): caminho_pergunta.set(self.copiar_imagem(filedialog.askopenfilename(filetypes=[("Imagens", "*.png *.jpg *.jpeg")])) or "")
        BotaoAnimado(frame, "Selecionar imagem da pergunta/opcional", escolher_pergunta, cor=COR_CINZA).pack(anchor="w", pady=5)
        entradas = []
        for i in range(1,5):
            linha = tk.Frame(frame, bg=COR_BRANCO); linha.pack(fill="x", pady=3)
            tk.Label(linha, text=f"Alternativa {i}", bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 10, "bold"), width=12).pack(side="left")
            texto = ttk.Entry(linha); texto.pack(side="left", fill="x", expand=True, padx=5)
            img_var = tk.StringVar(value="")
            def escolher(v=img_var): v.set(self.copiar_imagem(filedialog.askopenfilename(filetypes=[("Imagens", "*.png *.jpg *.jpeg")])) or "")
            BotaoAnimado(linha, "Imagem", escolher, cor=COR_CINZA).pack(side="right")
            entradas.append((texto, img_var))
        linha2 = tk.Frame(frame, bg=COR_BRANCO); linha2.pack(fill="x", pady=8)
        correta = ttk.Combobox(linha2, values=["1", "2", "3", "4"], state="readonly", width=10); correta.set("1")
        modo = ttk.Combobox(linha2, values=["Fácil", "Médio", "Difícil"], state="readonly", width=15); modo.set("Fácil")
        tipo = ttk.Combobox(linha2, values=["identificacao", "multipla_escolha", "associacao"], state="readonly", width=20); tipo.set("multipla_escolha")
        for txt, wid in [("Correta", correta), ("Modo", modo), ("Tipo", tipo)]:
            tk.Label(linha2, text=txt, bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 10, "bold")).pack(side="left", padx=(8,2)); wid.pack(side="left")
        label("Dica")
        dica = ttk.Entry(frame); dica.pack(fill="x")
        def salvar():
            if not enunciado.get("1.0","end").strip():
                self.mostrar_mensagem("Atenção", "Informe o enunciado.", "info"); return
            conn = conectar()
            id_modo = {"Fácil":1,"Médio":2,"Difícil":3}[modo.get()]
            idx_correta = int(correta.get())
            conn.execute("INSERT INTO perguntas (id_modo,id_professor_criador,enunciado,imagem_url,tipo_pergunta,resposta_correta_texto,pontuacao) VALUES (?,?,?,?,?,?,?)", (id_modo, self.usuario["id_usuario"], enunciado.get("1.0","end").strip(), caminho_pergunta.get(), tipo.get(), entradas[idx_correta-1][0].get(), 10))
            idp = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            for ordem, (txt, img) in enumerate(entradas, start=1):
                conn.execute("INSERT INTO alternativas (id_pergunta,texto,imagem_url,correta,ordem) VALUES (?,?,?,?,?)", (idp, txt.get(), img.get(), 1 if ordem==idx_correta else 0, ordem))
            if dica.get(): conn.execute("INSERT INTO dicas (id_pergunta,texto_dica) VALUES (?,?)", (idp, dica.get()))
            conn.commit(); conn.close()
            self.mostrar_mensagem("Pergunta cadastrada", "A pergunta e suas alternativas com imagens foram salvas no banco.", "sucesso", self.tela_listar_questoes)
        botoes = tk.Frame(frame, bg=COR_BRANCO); botoes.pack(fill="x", pady=10)
        BotaoAnimado(botoes, "Salvar", salvar).pack(side="right", padx=5)
        BotaoAnimado(botoes, "Voltar", self.tela_professor, cor=COR_CINZA).pack(side="right", padx=5)

    def copiar_imagem(self, origem):
        if not origem: return ""
        try:
            origem = Path(origem)
            destino = IMG_DIR / f"{datetime.now().strftime('%Y%m%d%H%M%S%f')}_{origem.name}"
            shutil.copy(origem, destino)
            return str(destino)
        except Exception:
            return ""

    def montar_tabela(self, parent, colunas, larguras):
        tabela = ttk.Treeview(parent, columns=colunas, show="headings")
        for c in colunas:
            tabela.heading(c, text=c.replace("_", " ").capitalize())
            tabela.column(c, width=larguras.get(c, 120))
        tabela.pack(fill="both", expand=True)
        return tabela

    def tela_listar_questoes(self):
        self.limpar(); self.cabecalho("Perguntas Cadastradas")
        frame = tk.Frame(self.root, bg=COR_FUNDO); frame.pack(fill="both", expand=True, padx=25, pady=20)
        tabela = self.montar_tabela(frame, ("id", "modo", "tipo", "enunciado"), {"id":60,"modo":100,"tipo":160,"enunciado":700})
        conn=conectar()
        for r in conn.execute("SELECT p.id_pergunta, m.nome_modo, p.tipo_pergunta, p.enunciado FROM perguntas p JOIN modos_jogo m ON m.id_modo=p.id_modo ORDER BY p.id_pergunta DESC"):
            tabela.insert("", "end", values=(r[0],r[1],r[2],r[3]))
        conn.close(); BotaoAnimado(frame, "Voltar", self.tela_professor, cor=COR_CINZA).pack(pady=12)

    def tela_usuarios(self):
        self.limpar(); self.cabecalho("Usuários Cadastrados")
        frame = tk.Frame(self.root, bg=COR_FUNDO); frame.pack(fill="both", expand=True, padx=25, pady=20)
        tabela = self.montar_tabela(frame, ("id", "nome", "email", "tipo"), {"id":60,"nome":280,"email":360,"tipo":120})
        conn=conectar()
        for r in conn.execute("SELECT id_usuario,nome,email,tipo_usuario FROM usuarios ORDER BY id_usuario DESC"):
            tabela.insert("", "end", values=(r[0],r[1],r[2],r[3]))
        conn.close(); BotaoAnimado(frame, "Voltar", self.tela_professor, cor=COR_CINZA).pack(pady=12)

    def tela_relatorios(self):
        self.limpar(); self.cabecalho("Relatórios de Desempenho")
        frame = tk.Frame(self.root, bg=COR_FUNDO); frame.pack(fill="both", expand=True, padx=25, pady=20)
        tabela = self.montar_tabela(frame, ("aluno", "pontos", "acertos", "erros", "total", "data"), {"aluno":260,"pontos":90,"acertos":90,"erros":90,"total":90,"data":180})
        conn=conectar()
        for r in conn.execute("SELECT u.nome,p.pontuacao_total,p.quantidade_acertos,p.quantidade_erros,p.total_perguntas,p.data_fim FROM partidas p JOIN usuarios u ON u.id_usuario=p.id_aluno WHERE p.status_partida='finalizada' ORDER BY p.id_partida DESC"):
            tabela.insert("", "end", values=(r[0],r[1],r[2],r[3],r[4],r[5]))
        conn.close(); BotaoAnimado(frame, "Voltar", self.voltar_por_tipo, cor=COR_CINZA).pack(pady=12)

    def tela_ranking(self):
        self.limpar(); self.cabecalho("Ranking Geral")
        frame = tk.Frame(self.root, bg=COR_FUNDO); frame.pack(fill="both", expand=True, padx=25, pady=20)
        tabela = self.montar_tabela(frame, ("posição", "aluno", "melhor_pontuação", "acertos", "total"), {"posição":90,"aluno":320,"melhor_pontuação":160,"acertos":100,"total":90})
        conn=conectar()
        for pos, r in enumerate(conn.execute("SELECT u.nome, MAX(p.pontuacao_total), MAX(p.quantidade_acertos), MAX(p.total_perguntas) FROM partidas p JOIN usuarios u ON u.id_usuario=p.id_aluno WHERE p.status_partida='finalizada' GROUP BY u.id_usuario ORDER BY MAX(p.pontuacao_total) DESC, MAX(p.quantidade_acertos) DESC"), start=1):
            tabela.insert("", "end", values=(pos,r[0],r[1],r[2],r[3]))
        conn.close(); BotaoAnimado(frame, "Voltar", self.voltar_por_tipo, cor=COR_CINZA).pack(pady=12)

    def voltar_por_tipo(self):
        if self.usuario and self.usuario.get("tipo_usuario") == "professor": self.tela_professor()
        elif self.usuario and self.usuario.get("tipo_usuario") == "aluno": self.tela_menu_aluno()
        else: self.tela_inicial()


if __name__ == "__main__":
    iniciar_banco()
    root = tk.Tk()
    app = JogoQuimica(root)
    root.mainloop()
