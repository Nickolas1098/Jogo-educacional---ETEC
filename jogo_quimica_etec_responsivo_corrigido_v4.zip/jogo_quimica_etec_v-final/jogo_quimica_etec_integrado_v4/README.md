# Jogo Química ETEC - MySQL vinculado ao bdetecscript.sql

Esta versão está vinculada ao banco MySQL definido no arquivo `bdetecscript.sql` enviado.

Banco usado por padrão: `laboratorio_game`.

O sistema cria automaticamente as tabelas necessárias na primeira execução, seguindo a estrutura do script SQL.

## Como executar

1. Abra o MySQL pelo XAMPP/WAMP ou outro servidor local.
2. Instale as dependências:

```bash
pip install -r requirements.txt
```

3. Execute:

```bash
python main.py
```

## Configuração padrão do MySQL

- Host: `localhost`
- Porta: `3306`
- Usuário: `root`
- Senha: vazia
- Banco: `laboratorio_game`

Se seu MySQL tiver senha, execute antes:

```powershell
set MYSQL_PASSWORD=sua_senha
python main.py
```

Se quiser usar outro banco:

```powershell
set MYSQL_DATABASE=nome_do_banco
python main.py
```

## Importar o SQL manualmente

Também deixei um importador do script SQL. Ele recria o banco `laboratorio_game`, pois o SQL contém `DROP DATABASE`.

```bash
python importar_bdetecscript.py
```

Depois execute:

```bash
python main.py
```

## Logins de teste

Aluno: `aluno.demo@aluno.cps.sp.gov.br` / `123456`

Professor: `professor.demo@cps.sp.gov.br` / `123456`


## Configuração MySQL corrigida

Host: localhost
Porta: 3306
Usuário: root
Senha: 123456
Banco: laboratorio_game

Para executar:

```bash
pip install -r requirements.txt
python main.py
```
