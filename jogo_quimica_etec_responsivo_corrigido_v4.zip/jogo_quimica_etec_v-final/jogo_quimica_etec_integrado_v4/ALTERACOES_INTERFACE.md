# Alterações realizadas

- Adicionadas 5 perguntas novas do tipo `identificacao` no banco inicial.
- As perguntas novas usam imagens nas alternativas para funcionar no layout de identificação.
- Melhorada a tela Banco de Questões com:
  - cards de resumo;
  - busca por enunciado/resposta;
  - filtro por modo;
  - filtro por tipo;
  - filtro por status;
  - tabela com linhas divisórias reais;
  - colunas alinhadas com o cabeçalho;
  - seleção de linha com destaque visual.
- Criado arquivo `main.py` para facilitar a execução do projeto.

Para rodar:

```bash
python main.py
```

## Atualização das imagens dos materiais
- Substituídas as imagens desenhadas por imagens reais enviadas pelo usuário.
- As imagens são carregadas com Pillow no código e padronizadas automaticamente para o tamanho usado no jogo.
- Arquivos adicionados em `assets_materiais/` e gerados em `imagens_materiais/` ao iniciar o sistema.
