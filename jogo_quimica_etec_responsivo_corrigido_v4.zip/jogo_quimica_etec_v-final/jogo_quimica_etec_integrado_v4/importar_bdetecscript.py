import os
from pathlib import Path
import pymysql

APP_DIR = Path(__file__).resolve().parent
SQL_SCRIPT_PATH = APP_DIR / "bdetecscript.sql"

MYSQL_HOST = os.getenv("MYSQL_HOST", "localhost")
MYSQL_PORT = int(os.getenv("MYSQL_PORT", "3306"))
MYSQL_USER = os.getenv("MYSQL_USER", "root")
MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "")

print("Importando bdetecscript.sql no MySQL...")
print("Atenção: o script possui DROP DATABASE e recriará o banco laboratorio_game.")

sql = SQL_SCRIPT_PATH.read_text(encoding="utf-8")

conn = pymysql.connect(
    host=MYSQL_HOST,
    port=MYSQL_PORT,
    user=MYSQL_USER,
    password=MYSQL_PASSWORD,
    charset="utf8mb4",
    autocommit=True,
)

try:
    with conn.cursor() as cur:
        comandos = []
        atual = []
        for linha in sql.splitlines():
            linha_strip = linha.strip()
            if not linha_strip or linha_strip.startswith("--"):
                continue
            atual.append(linha)
            if linha_strip.endswith(";"):
                comandos.append("\n".join(atual).rstrip(";"))
                atual = []

        for comando in comandos:
            if comando.strip():
                cur.execute(comando)

    print("Banco importado com sucesso.")
finally:
    conn.close()
