import tkinter as tk
from tkinter import ttk, filedialog
import os
from pathlib import Path

try:
    import pymysql
except ImportError:
    raise SystemExit("Instale o conector MySQL antes de executar: pip install pymysql")
from datetime import datetime
import hashlib
import shutil
import ctypes

try:
    from PIL import Image, ImageTk, ImageDraw, ImageFont
except ImportError:
    raise SystemExit("Instale a biblioteca Pillow antes de executar: pip install pillow")

APP_DIR = Path(__file__).resolve().parent
# Configuração do banco MySQL.
# Por padrão, o sistema usa o banco solicitado: bdetecscript.
MYSQL_HOST = os.getenv("MYSQL_HOST", "localhost")
MYSQL_PORT = int(os.getenv("MYSQL_PORT", "3306"))
MYSQL_USER = os.getenv("MYSQL_USER", "root")
MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "")
MYSQL_DATABASE = os.getenv("MYSQL_DATABASE", "laboratorio_game")
SQL_SCRIPT_PATH = APP_DIR / "bdetecscript.sql"
IMG_DIR = APP_DIR / "imagens_materiais"
IMG_DIR.mkdir(exist_ok=True)
LOGO_ETEC_PATH = APP_DIR / "logo_etec_modelo.png"
LOGO_CPS_PATH = APP_DIR / "logo_cps_modelo.png"

COR_VERMELHO = "#941611"
COR_VERMELHO_ESCURO = "#6F0F0C"
COR_CINZA = "#4A555C"
COR_FUNDO = "#F5F6F8"
COR_BRANCO = "#FFFFFF"
COR_BORDA = "#DDDDDD"
COR_VERDE = "#2E7D32"
COR_VERDE_CLARO = "#E8F5E9"
COR_ERRO = "#C62828"
COR_ERRO_CLARO = "#FFEBEE"
COR_DESTAQUE = "#F7F1F1"
COR_PRETO_TEXTO = "#101828"
COR_SOMBRA = "#E5E7EB"


def hash_senha(senha: str) -> str:
    return hashlib.sha256(senha.encode("utf-8")).hexdigest()


class Linha(dict):
    """Permite acessar os resultados por nome da coluna ou por índice."""
    def __init__(self, colunas, valores):
        super().__init__(zip(colunas, valores))
        self._valores = tuple(valores)

    def __getitem__(self, chave):
        if isinstance(chave, int):
            return self._valores[chave]
        return super().__getitem__(chave)


class ResultadoMySQL:
    def __init__(self, cursor):
        self.cursor = cursor
        self.colunas = [c[0] for c in cursor.description] if cursor.description else []
        self.lastrowid = cursor.lastrowid

    def fetchone(self):
        linha = self.cursor.fetchone()
        if linha is None:
            return None
        return Linha(self.colunas, linha)

    def fetchall(self):
        return [Linha(self.colunas, linha) for linha in self.cursor.fetchall()]

    def __iter__(self):
        for linha in self.cursor.fetchall():
            yield Linha(self.colunas, linha)


class ConexaoMySQL:
    def __init__(self, database=True):
        self.conn = pymysql.connect(
         host='localhost',
            port=3306,
            user='root',
            password='tinCTrom',
            database='laboratorio_game' if database else None,
            charset="utf8mb4",
            autocommit=False
        )
        self.lastrowid = None

    def _sql(self, sql):
        return sql.replace("?", "%s")

    def execute(self, sql, params=None):
        cur = self.conn.cursor()
        cur.execute(self._sql(sql), params or ())
        self.lastrowid = cur.lastrowid
        return ResultadoMySQL(cur)

    def executemany(self, sql, seq_params):
        cur = self.conn.cursor()
        cur.executemany(self._sql(sql), seq_params)
        self.lastrowid = cur.lastrowid
        return ResultadoMySQL(cur)

    def cursor(self):
        return self

    def commit(self):
        self.conn.commit()

    def rollback(self):
        self.conn.rollback()

    def close(self):
        self.conn.close()


def conectar(database=True):
    return ConexaoMySQL(database=database)



def criar_logos_institucionais():
    if not LOGO_ETEC_PATH.exists():
        img = Image.new("RGBA", (360, 110), (255, 255, 255, 0))
        draw = ImageDraw.Draw(img)

        try:
            fonte_etec = ImageFont.truetype("arialbd.ttf", 58)
            fonte_sub = ImageFont.truetype("arialbd.ttf", 14)
        except Exception:
            fonte_etec = ImageFont.load_default()
            fonte_sub = ImageFont.load_default()

        draw.text((0, 0), "Etec", fill=COR_CINZA, font=fonte_etec)
        draw.text((4, 72), "Escola Técnica Estadual", fill=COR_VERMELHO, font=fonte_sub)
        img.save(LOGO_ETEC_PATH)

    if not LOGO_CPS_PATH.exists():
        img = Image.new("RGBA", (290, 95), (255, 255, 255, 0))
        draw = ImageDraw.Draw(img)

        try:
            fonte_cps = ImageFont.truetype("arialbd.ttf", 48)
            fonte_txt = ImageFont.truetype("arial.ttf", 17)
        except Exception:
            fonte_cps = ImageFont.load_default()
            fonte_txt = ImageFont.load_default()

        draw.text((0, 8), "CPS", fill=COR_VERMELHO, font=fonte_cps)
        draw.text((120, 25), "Centro", fill=COR_PRETO_TEXTO, font=fonte_txt)
        draw.text((120, 47), "Paula Souza", fill=COR_PRETO_TEXTO, font=fonte_txt)
        img.save(LOGO_CPS_PATH)

    return str(LOGO_ETEC_PATH), str(LOGO_CPS_PATH)

def fonte_padrao(tamanho=20, negrito=False):
    opcoes = [
        "arialbd.ttf" if negrito else "arial.ttf",
        "DejaVuSans-Bold.ttf" if negrito else "DejaVuSans.ttf"
    ]

    for nome in opcoes:
        try:
            return ImageFont.truetype(nome, tamanho)
        except Exception:
            pass

    return ImageFont.load_default()


def rotulo_material(draw, texto):
    # As imagens do jogo não exibem o nome do material, para não entregar a resposta.
    return

def criar_imagem_material(nome: str, arquivo: str) -> str:
    caminho = IMG_DIR / arquivo

    img = Image.new("RGB", (420, 300), "white")
    draw = ImageDraw.Draw(img)

    draw.rounded_rectangle(
        (10, 10, 410, 290),
        radius=22,
        fill="white",
        outline="#CFCFCF",
        width=3
    )

    azul_vidro = "#A8DFF0"
    azul_contorno = "#327C96"
    azul_liquido = "#74C0FC"
    verde_liquido = "#52B788"
    cinza = COR_CINZA
    vermelho = "#D62828"

    nome_base = nome.lower()

    if "béquer" in nome_base or "bequer" in nome_base:
        draw.line((135, 70, 160, 230), fill=azul_contorno, width=6)
        draw.line((285, 70, 260, 230), fill=azul_contorno, width=6)
        draw.line((160, 230, 260, 230), fill=azul_contorno, width=6)
        draw.ellipse((130, 50, 290, 90), outline=azul_contorno, width=6)
        draw.rectangle((160, 155, 260, 225), fill="#BDE0FE")
        draw.ellipse((160, 140, 260, 175), fill=azul_liquido, outline=azul_contorno, width=3)
        for y in [105, 130, 155, 180, 205]:
            draw.line((268, y, 288, y), fill=cinza, width=2)
        rotulo_material(draw, "Béquer")

    elif "funil" in nome_base:
        draw.polygon(
            [(105, 70), (315, 70), (240, 175), (180, 175)],
            outline=azul_contorno,
            fill="#E7F7FB"
        )
        draw.line((180, 175, 180, 235), fill=azul_contorno, width=6)
        draw.line((240, 175, 240, 235), fill=azul_contorno, width=6)
        draw.line((180, 235, 240, 235), fill=azul_contorno, width=6)
        draw.arc((105, 45, 315, 95), 0, 180, fill=azul_contorno, width=5)
        draw.polygon([(135, 90), (285, 90), (235, 150), (185, 150)], fill="#CDEFFD")
        rotulo_material(draw, "Funil analítico")

    elif "proveta" in nome_base:
        draw.rectangle((175, 65, 245, 230), outline=azul_contorno, width=6, fill="#E7F7FB")
        draw.ellipse((175, 45, 245, 85), outline=azul_contorno, width=6, fill="#F8FDFF")
        draw.rectangle((182, 155, 238, 225), fill="#BDE0FE")
        draw.ellipse((182, 140, 238, 170), fill=azul_liquido, outline=azul_contorno, width=2)
        draw.rectangle((135, 230, 285, 255), fill="#E0E0E0", outline=cinza, width=3)
        for y in range(95, 210, 22):
            draw.line((245, y, 270, y), fill=cinza, width=2)
        rotulo_material(draw, "Proveta")

    elif "pipeta" in nome_base:
        draw.line((100, 220, 315, 75), fill=azul_contorno, width=9)
        draw.line((112, 230, 327, 85), fill="#DDF7FF", width=5)
        draw.ellipse((192, 130, 255, 190), outline=azul_contorno, width=5, fill="#E7F7FB")
        draw.line((92, 225, 118, 244), fill=azul_contorno, width=5)
        draw.line((310, 70, 338, 55), fill=azul_contorno, width=5)
        rotulo_material(draw, "Pipeta")

    elif "cápsula" in nome_base or "capsula" in nome_base:
        draw.ellipse((105, 125, 315, 220), fill="#F7F7F7", outline=cinza, width=5)
        draw.arc((105, 95, 315, 200), 0, 180, fill=cinza, width=5)
        draw.ellipse((135, 140, 285, 195), fill="#FFFFFF", outline="#BDBDBD", width=2)
        draw.polygon([(300, 160), (365, 135), (322, 190)], fill="#F7F7F7", outline=cinza)
        rotulo_material(draw, "Cápsula")

    elif "termômetro" in nome_base or "termometro" in nome_base:
        draw.rounded_rectangle((190, 55, 230, 215), radius=18, fill="#F7F7F7", outline=cinza, width=4)
        draw.ellipse((170, 195, 250, 275), fill=vermelho, outline=cinza, width=4)
        draw.rectangle((202, 90, 218, 230), fill=vermelho)
        for y in range(80, 190, 22):
            draw.line((230, y, 255, y), fill=cinza, width=2)
        rotulo_material(draw, "Termômetro")

    elif "tripé" in nome_base or "tripe" in nome_base:
        draw.ellipse((120, 90, 300, 130), outline=cinza, width=6)
        draw.line((145, 125, 105, 240), fill=cinza, width=6)
        draw.line((210, 130, 210, 250), fill=cinza, width=6)
        draw.line((275, 125, 315, 240), fill=cinza, width=6)
        draw.line((90, 240, 125, 240), fill=cinza, width=5)
        draw.line((195, 250, 225, 250), fill=cinza, width=5)
        draw.line((300, 240, 335, 240), fill=cinza, width=5)
        rotulo_material(draw, "Tripé")

    elif "almofariz" in nome_base:
        draw.ellipse((110, 125, 310, 205), fill="#EEEEEE", outline=cinza, width=5)
        draw.arc((110, 105, 310, 245), 0, 180, fill=cinza, width=5)
        draw.polygon([(120, 160), (300, 160), (270, 245), (150, 245)], fill="#F5F5F5", outline=cinza)
        draw.line((290, 70, 190, 175), fill=cinza, width=15)
        draw.ellipse((270, 55, 315, 90), fill="#DDDDDD", outline=cinza, width=3)
        rotulo_material(draw, "Almofariz")

    elif "destilação" in nome_base or "destilacao" in nome_base:
        draw.ellipse((110, 155, 210, 250), fill="#E7F7FB", outline=azul_contorno, width=5)
        draw.rectangle((145, 85, 175, 165), fill="#E7F7FB", outline=azul_contorno, width=5)
        draw.line((170, 110, 310, 110), fill=azul_contorno, width=8)
        draw.line((310, 110, 350, 160), fill=azul_contorno, width=8)
        draw.rectangle((250, 85, 340, 135), fill="#DDF7FF", outline=azul_contorno, width=4)
        draw.polygon([(110, 250), (210, 250), (170, 275), (150, 275)], fill=cinza)
        draw.rectangle((90, 275, 230, 285), fill=cinza)
        rotulo_material(draw, "Destilação")

    elif "filtração" in nome_base or "filtracao" in nome_base:
        draw.line((75, 50, 75, 240), fill=cinza, width=7)
        draw.rectangle((40, 240, 125, 255), fill="#D9D9D9", outline=cinza, width=3)
        draw.line((75, 105, 175, 105), fill=cinza, width=5)
        draw.rectangle((155, 92, 185, 118), fill="#F2C94C", outline=cinza, width=3)

        draw.polygon([(165, 110), (305, 110), (245, 205), (210, 205)], outline=azul_contorno, fill="#E7F7FB")
        draw.polygon([(190, 135), (280, 135), (245, 190), (210, 190)], outline=cinza, fill="#F5F5F5")
        draw.rectangle((210, 205, 245, 250), outline=azul_contorno, width=5, fill="#E7F7FB")

        draw.ellipse((150, 235, 310, 280), outline=azul_contorno, width=5, fill="#E7F7FB")
        draw.rectangle((155, 255, 305, 280), fill="#BDE0FE")
        draw.ellipse((155, 245, 305, 270), fill=azul_liquido, outline=azul_contorno, width=3)

        draw.polygon([(210, 45), (350, 80), (315, 140), (180, 100)], outline=azul_contorno, fill="#E7F7FB")
        draw.polygon([(220, 65), (330, 88), (305, 120), (195, 95)], fill=verde_liquido)
        draw.line((270, 135, 225, 170), fill="#2B2B2B", width=6)
        rotulo_material(draw, "Filtração simples")

    else:
        fonte = fonte_padrao(28, True)
        bbox = draw.textbbox((0, 0), nome, font=fonte)
        draw.text(
            ((420 - (bbox[2] - bbox[0])) / 2, 130),
            nome,
            fill=COR_CINZA,
            font=fonte
        )

    img.save(caminho)
    return str(caminho)


def iniciar_banco():
    criar_logos_institucionais()

    # Cria e seleciona o banco MySQL usado pelo script bdetecscript.sql.
    servidor = conectar(database=False)
    servidor.execute(f"CREATE DATABASE IF NOT EXISTS {MYSQL_DATABASE} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
    servidor.commit()
    servidor.close()

    conn = conectar()
    cur = conn.cursor()

    # Estrutura MySQL baseada no arquivo bdetecscript.sql.
    tabelas = [
        """
        CREATE TABLE IF NOT EXISTS turmas (
            id_turma INT AUTO_INCREMENT PRIMARY KEY,
            nome_turma VARCHAR(100) NOT NULL,
            ano_letivo YEAR NOT NULL,
            ativa BOOLEAN DEFAULT TRUE,
            data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS usuarios (
            id_usuario INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(120) NOT NULL,
            email VARCHAR(150) NOT NULL UNIQUE,
            senha_hash VARCHAR(255) NOT NULL,
            tipo_usuario ENUM('aluno', 'professor') NOT NULL,
            id_turma INT NULL,
            ativo BOOLEAN DEFAULT TRUE,
            data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_usuario_turma FOREIGN KEY (id_turma)
                REFERENCES turmas(id_turma) ON DELETE SET NULL ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS modos_jogo (
            id_modo INT AUTO_INCREMENT PRIMARY KEY,
            nome_modo VARCHAR(50) NOT NULL,
            descricao VARCHAR(255),
            nivel INT NOT NULL,
            ativo BOOLEAN DEFAULT TRUE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS perguntas (
            id_pergunta INT AUTO_INCREMENT PRIMARY KEY,
            id_modo INT NOT NULL,
            id_professor_criador INT NULL,
            enunciado VARCHAR(255) NOT NULL,
            imagem_url VARCHAR(255) NULL,
            tipo_pergunta ENUM('identificacao', 'multipla_escolha', 'associacao') DEFAULT 'multipla_escolha',
            resposta_correta_texto VARCHAR(255) NULL,
            pontuacao INT DEFAULT 10,
            ativa BOOLEAN DEFAULT TRUE,
            data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_pergunta_modo FOREIGN KEY (id_modo)
                REFERENCES modos_jogo(id_modo) ON DELETE RESTRICT ON UPDATE CASCADE,
            CONSTRAINT fk_pergunta_professor FOREIGN KEY (id_professor_criador)
                REFERENCES usuarios(id_usuario) ON DELETE SET NULL ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS alternativas (
            id_alternativa INT AUTO_INCREMENT PRIMARY KEY,
            id_pergunta INT NOT NULL,
            texto VARCHAR(255) NULL,
            imagem_url VARCHAR(255) NULL,
            correta BOOLEAN DEFAULT FALSE,
            ordem INT DEFAULT 1,
            CONSTRAINT fk_alternativa_pergunta FOREIGN KEY (id_pergunta)
                REFERENCES perguntas(id_pergunta) ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS dicas (
            id_dica INT AUTO_INCREMENT PRIMARY KEY,
            id_pergunta INT NOT NULL,
            texto_dica VARCHAR(255) NOT NULL,
            CONSTRAINT fk_dica_pergunta FOREIGN KEY (id_pergunta)
                REFERENCES perguntas(id_pergunta) ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS partidas (
            id_partida INT AUTO_INCREMENT PRIMARY KEY,
            id_aluno INT NOT NULL,
            id_modo INT NOT NULL,
            pontuacao_total INT DEFAULT 0,
            quantidade_acertos INT DEFAULT 0,
            quantidade_erros INT DEFAULT 0,
            total_perguntas INT DEFAULT 0,
            data_inicio DATETIME DEFAULT CURRENT_TIMESTAMP,
            data_fim DATETIME NULL,
            status_partida ENUM('em_andamento', 'finalizada', 'cancelada') DEFAULT 'em_andamento',
            CONSTRAINT fk_partida_aluno FOREIGN KEY (id_aluno)
                REFERENCES usuarios(id_usuario) ON DELETE RESTRICT ON UPDATE CASCADE,
            CONSTRAINT fk_partida_modo FOREIGN KEY (id_modo)
                REFERENCES modos_jogo(id_modo) ON DELETE RESTRICT ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS respostas_partida (
            id_resposta_partida INT AUTO_INCREMENT PRIMARY KEY,
            id_partida INT NOT NULL,
            id_pergunta INT NOT NULL,
            id_alternativa INT NULL,
            resposta_texto VARCHAR(255) NULL,
            correta BOOLEAN NOT NULL,
            pontos_obtidos INT DEFAULT 0,
            data_resposta DATETIME DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_resposta_partida FOREIGN KEY (id_partida)
                REFERENCES partidas(id_partida) ON DELETE CASCADE ON UPDATE CASCADE,
            CONSTRAINT fk_resposta_pergunta FOREIGN KEY (id_pergunta)
                REFERENCES perguntas(id_pergunta) ON DELETE RESTRICT ON UPDATE CASCADE,
            CONSTRAINT fk_resposta_alternativa FOREIGN KEY (id_alternativa)
                REFERENCES alternativas(id_alternativa) ON DELETE SET NULL ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS ajudas_utilizadas (
            id_ajuda_utilizada INT AUTO_INCREMENT PRIMARY KEY,
            id_partida INT NOT NULL,
            id_pergunta INT NOT NULL,
            tipo_ajuda ENUM('dica', 'eliminar_alternativas') NOT NULL,
            data_uso DATETIME DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_ajuda_partida FOREIGN KEY (id_partida)
                REFERENCES partidas(id_partida) ON DELETE CASCADE ON UPDATE CASCADE,
            CONSTRAINT fk_ajuda_pergunta FOREIGN KEY (id_pergunta)
                REFERENCES perguntas(id_pergunta) ON DELETE RESTRICT ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
    ]

    for sql in tabelas:
        cur.execute(sql)

    for idx in [
        "CREATE INDEX idx_usuarios_tipo ON usuarios(tipo_usuario)",
        "CREATE INDEX idx_perguntas_modo ON perguntas(id_modo)",
        "CREATE INDEX idx_partidas_aluno ON partidas(id_aluno)",
        "CREATE INDEX idx_partidas_modo ON partidas(id_modo)",
        "CREATE INDEX idx_respostas_partida ON respostas_partida(id_partida)",
    ]:
        try:
            cur.execute(idx)
        except Exception:
            pass

    if cur.execute("SELECT COUNT(*) AS total FROM turmas").fetchone()[0] == 0:
        cur.execute("INSERT INTO turmas (nome_turma, ano_letivo) VALUES (?, ?)", ("1º Química A", datetime.now().year))

    if cur.execute("SELECT COUNT(*) AS total FROM modos_jogo").fetchone()[0] == 0:
        cur.executemany("INSERT INTO modos_jogo (nome_modo, descricao, nivel) VALUES (?, ?, ?)", [
            ("Fácil", "Identificação inicial de materiais", 1),
            ("Médio", "Função dos materiais", 2),
            ("Difícil", "Sistemas experimentais", 3),
        ])

    if cur.execute("SELECT COUNT(*) AS total FROM usuarios").fetchone()[0] == 0:
        cur.executemany("""
            INSERT INTO usuarios (nome, email, senha_hash, tipo_usuario, id_turma)
            VALUES (?, ?, ?, ?, ?)
        """, [
            ("Aluno Demo", "aluno.demo@aluno.cps.sp.gov.br", hash_senha("123456"), "aluno", 1),
            ("Professor Demo", "professor.demo@cps.sp.gov.br", hash_senha("123456"), "professor", None),
        ])

    # Imagens padrão usadas nas perguntas iniciais e nas perguntas extras de identificação.
    # Elas precisam ser criadas fora do IF abaixo, pois o banco pode já ter perguntas
    # e ainda assim precisar inserir as 5 novas perguntas de identificação.
    img_bequer = criar_imagem_material("Béquer", "bequer.png")
    img_funil = criar_imagem_material("Funil", "funil.png")
    img_proveta = criar_imagem_material("Proveta", "proveta.png")
    img_capsula = criar_imagem_material("Cápsula", "capsula.png")
    img_destilacao = criar_imagem_material("Destilação", "destilacao.png")
    img_pipeta = criar_imagem_material("Pipeta", "pipeta.png")
    img_tripe = criar_imagem_material("Tripé", "tripe.png")
    img_termometro = criar_imagem_material("Termômetro", "termometro.png")
    img_almofariz = criar_imagem_material("Almofariz", "almofariz.png")
    img_filtro = criar_imagem_material("Filtração simples", "filtracao_simples.png")

    if cur.execute("SELECT COUNT(*) AS total FROM perguntas").fetchone()[0] == 0:
        def inserir_pergunta(id_modo, enunciado, imagem, tipo, correta_texto, pontuacao, dica, alternativas):
            cur.execute("""
                INSERT INTO perguntas (id_modo, id_professor_criador, enunciado, imagem_url, tipo_pergunta, resposta_correta_texto, pontuacao)
                VALUES (?, 2, ?, ?, ?, ?, ?)
            """, (id_modo, enunciado, imagem, tipo, correta_texto, pontuacao))
            idp = cur.lastrowid
            for ordem, (texto, img, correta) in enumerate(alternativas, start=1):
                cur.execute("""
                    INSERT INTO alternativas (id_pergunta, texto, imagem_url, correta, ordem)
                    VALUES (?, ?, ?, ?, ?)
                """, (idp, texto, img, 1 if correta else 0, ordem))
            cur.execute("INSERT INTO dicas (id_pergunta, texto_dica) VALUES (?, ?)", (idp, dica))

        inserir_pergunta(
            1,
            "Qual o nome do material a seguir?",
            img_bequer,
            "multipla_escolha",
            "Béquer",
            10,
            "É uma vidraria cilíndrica comum em laboratório.",
            [("Funil analítico", "", False), ("Béquer", "", True), ("Proveta", "", False), ("Pipeta", "", False)]
        )
        inserir_pergunta(
            1,
            "Qual o nome do material a seguir?",
            img_funil,
            "multipla_escolha",
            "Funil analítico",
            10,
            "É usado com papel de filtro em processos de filtração simples.",
            [("Funil raiado", "", False), ("Funil de Büchner", "", False), ("Funil analítico", "", True), ("Funil de porcelana", "", False)]
        )
        inserir_pergunta(
            2,
            "Qual o nome do material a seguir?",
            img_proveta,
            "multipla_escolha",
            "Proveta",
            10,
            "Possui marcações graduadas em seu corpo.",
            [("Béquer", "", False), ("Proveta", "", True), ("Pipeta", "", False), ("Tubo de ensaio", "", False)]
        )
        inserir_pergunta(
            2,
            "Qual o nome do material a seguir?",
            img_capsula,
            "multipla_escolha",
            "Cápsula de porcelana",
            10,
            "É feita de porcelana e suporta aquecimento.",
            [("Pipeta", "", False), ("Funil", "", False), ("Cápsula de porcelana", "", True), ("Termômetro", "", False)]
        )
        inserir_pergunta(
            3,
            "Qual processo experimental está representado na imagem?",
            img_filtro,
            "multipla_escolha",
            "Filtração simples",
            10,
            "O líquido atravessa um papel de filtro apoiado em um funil.",
            [("Filtração a vácuo", "", False), ("Cristalização", "", False), ("Filtração simples", "", True), ("Destilação simples", "", False)]
        )


    # Garante 5 perguntas adicionais no modo de identificação, mesmo quando o banco já existe.
    identificacao_padrao = [
        (1, "Identifique o material mostrado na imagem.", img_pipeta, "Pipeta", "Instrumento usado para medir e transferir pequenos volumes de líquido.",
         [("Pipeta", img_pipeta, True), ("Béquer", img_bequer, False), ("Proveta", img_proveta, False), ("Funil", img_funil, False)]),
        (1, "Qual material de laboratório está destacado?", img_termometro, "Termômetro", "Serve para medir temperatura durante o experimento.",
         [("Termômetro", img_termometro, True), ("Tripé", img_tripe, False), ("Pipeta", img_pipeta, False), ("Almofariz", img_almofariz, False)]),
        (1, "Observe a imagem e marque o nome correto do material.", img_almofariz, "Almofariz", "É usado para triturar sólidos com o pistilo.",
         [("Almofariz", img_almofariz, True), ("Cápsula de porcelana", img_capsula, False), ("Béquer", img_bequer, False), ("Funil", img_funil, False)]),
        (1, "Identifique o equipamento utilizado para apoiar materiais durante aquecimento.", img_tripe, "Tripé", "Normalmente sustenta a tela de amianto ou outros materiais no aquecimento.",
         [("Tripé", img_tripe, True), ("Proveta", img_proveta, False), ("Pipeta", img_pipeta, False), ("Termômetro", img_termometro, False)]),
        (1, "Qual é o material representado na imagem?", img_funil, "Funil analítico", "É usado para transferir líquidos e auxiliar na filtração.",
         [("Funil analítico", img_funil, True), ("Béquer", img_bequer, False), ("Almofariz", img_almofariz, False), ("Cápsula de porcelana", img_capsula, False)]),
    ]

    prof = cur.execute("SELECT id_usuario FROM usuarios WHERE tipo_usuario='professor' ORDER BY id_usuario LIMIT 1").fetchone()
    id_prof = prof[0] if prof else None
    for id_modo, enunciado, imagem, correta_texto, dica, alternativas in identificacao_padrao:
        existe = cur.execute(
            "SELECT COUNT(*) FROM perguntas WHERE tipo_pergunta='identificacao' AND resposta_correta_texto=?",
            (correta_texto,)
        ).fetchone()[0]
        if existe:
            continue
        cur.execute("""
            INSERT INTO perguntas (id_modo, id_professor_criador, enunciado, imagem_url, tipo_pergunta, resposta_correta_texto, pontuacao)
            VALUES (?, ?, ?, ?, 'identificacao', ?, 10)
        """, (id_modo, id_prof, enunciado, imagem, correta_texto))
        idp = cur.lastrowid
        for ordem, (texto, img, correta) in enumerate(alternativas, start=1):
            cur.execute("""
                INSERT INTO alternativas (id_pergunta, texto, imagem_url, correta, ordem)
                VALUES (?, ?, ?, ?, ?)
            """, (idp, texto, img, 1 if correta else 0, ordem))
        cur.execute("INSERT INTO dicas (id_pergunta, texto_dica) VALUES (?, ?)", (idp, dica))

    # Ajusta as questões de identificação para o formato correto:
    # o enunciado pergunta qual imagem representa o material, e as alternativas exibem imagens.
    perguntas_ident = cur.execute("""
        SELECT id_pergunta, resposta_correta_texto
        FROM perguntas
        WHERE tipo_pergunta='identificacao'
    """).fetchall()
    for pergunta in perguntas_ident:
        resposta = pergunta["resposta_correta_texto"] or "material informado"
        cur.execute(
            "UPDATE perguntas SET enunciado=?, imagem_url='' WHERE id_pergunta=?",
            (f"Qual das imagens representa o material: {resposta}?", pergunta["id_pergunta"])
        )

    conn.commit()
    conn.close()


class BotaoAnimado(tk.Button):
    def __init__(self, master, texto, comando, cor=COR_VERMELHO, largura=None):
        super().__init__(master, text=texto, command=comando, bg=cor, fg="white",
                         activebackground=COR_VERMELHO_ESCURO, activeforeground="white",
                         relief="flat", bd=0, cursor="hand2", font=("Arial", 12, "bold"),
                         padx=22, pady=12, width=largura)
        self.cor = cor
        self.bind("<Enter>", lambda e: self.config(bg=COR_VERMELHO_ESCURO, relief="raised"))
        self.bind("<Leave>", lambda e: self.config(bg=self.cor, relief="flat"))


class JogoQuimica:
    def __init__(self, root):
        self.root = root
        self.root.title("Química Experimental - ETEC")
        # Ajuste real para qualquer resolução e escala do Windows
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            try:
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass

        largura = self.root.winfo_screenwidth()
        altura = self.root.winfo_screenheight()

        # Escala visual baseada em 1366x768.
        # O código anterior usava Full HD como base e reduzia a escala em telas
        # de notebook, deixando o sistema minúsculo em algumas resoluções.
        self.escala = min(largura / 1366, altura / 768)
        self.escala = max(1.0, min(self.escala, 1.65))

        try:
            self.root.tk.call('tk', 'scaling', 1.25 * self.escala)
        except Exception:
            pass

        self.root.geometry(f"{largura}x{altura}+0+0")
        try:
            self.root.state("zoomed")
        except Exception:
            pass

        self.root.minsize(1180, 720)
        self.root.update_idletasks()
        self.root.configure(bg=COR_FUNDO)
        self.usuario = None
        self.questoes = []
        self.indice = 0
        self.pontos = 0
        self.acertos = 0
        self.erros = 0
        self.partida_id = None
        self.resposta_id = None
        self.alternativa_widgets = {}
        self.imagens_tk = []
        self.configurar_estilo()
        self.tela_inicial()

    def configurar_estilo(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(
            "Modern.Treeview",
            font=("Arial", 11),
            rowheight=38,
            background=COR_BRANCO,
            fieldbackground=COR_BRANCO,
            foreground=COR_PRETO_TEXTO,
            borderwidth=1,
            relief="solid"
        )
        style.configure(
            "Modern.Treeview.Heading",
            font=("Arial", 11, "bold"),
            background=COR_PRETO_TEXTO,
            foreground="white",
            relief="solid",
            borderwidth=1,
            padding=(10, 12)
        )
        style.map(
            "Modern.Treeview",
            background=[("selected", COR_VERMELHO)],
            foreground=[("selected", "white")]
        )
        style.configure("TEntry", padding=8, font=("Arial", max(11, int(11 * self.escala))))
        style.configure("TCombobox", padding=8, font=("Arial", max(11, int(11 * self.escala))))

    def fonte_ui(self, tamanho, negrito=False):
        estilo = "bold" if negrito else "normal"
        return ("Arial", max(9, int(tamanho * self.escala)), estilo)

    def medida_ui(self, valor):
        return max(1, int(valor * self.escala))

    def limpar(self):
        for widget in self.root.winfo_children():
            widget.destroy()
        self.imagens_tk = []

    def cabecalho(self, titulo):
        altura_header = self.medida_ui(112)
        altura_topo = self.medida_ui(92)
        frame = tk.Frame(self.root, bg=COR_BRANCO, height=altura_header)
        frame.pack(fill="x")
        frame.pack_propagate(False)

        topo = tk.Frame(frame, bg=COR_BRANCO, height=altura_topo)
        topo.pack(fill="x")
        topo.pack_propagate(False)

        try:
            etec_path, cps_path = criar_logos_institucionais()

            logo_etec = Image.open(etec_path).convert("RGBA")
            logo_etec.thumbnail((self.medida_ui(280), self.medida_ui(82)), Image.LANCZOS)
            self.logo_etec_tk = ImageTk.PhotoImage(logo_etec)
            tk.Label(topo, image=self.logo_etec_tk, bg=COR_BRANCO).pack(side="left", padx=self.medida_ui(28), pady=self.medida_ui(8))

            logo_cps = Image.open(cps_path).convert("RGBA")
            logo_cps.thumbnail((self.medida_ui(245), self.medida_ui(76)), Image.LANCZOS)
            self.logo_cps_tk = ImageTk.PhotoImage(logo_cps)
            tk.Label(topo, image=self.logo_cps_tk, bg=COR_BRANCO).pack(side="right", padx=self.medida_ui(36), pady=self.medida_ui(8))

        except Exception:
            tk.Label(
                topo,
                text="Etec",
                bg=COR_BRANCO,
                fg=COR_CINZA,
                font=self.fonte_ui(36, True)
            ).pack(side="left", padx=self.medida_ui(28))

            tk.Label(
                topo,
                text="CPS Centro Paula Souza",
                bg=COR_BRANCO,
                fg=COR_VERMELHO,
                font=self.fonte_ui(18, True)
            ).pack(side="right", padx=self.medida_ui(36))

        linha = tk.Frame(frame, bg=COR_VERMELHO, height=self.medida_ui(5))
        linha.pack(fill="x", side="bottom")

    def card(self, parent, padx=30, pady=25):
        card = tk.Frame(
            parent,
            bg=COR_BRANCO,
            padx=padx,
            pady=pady,
            highlightbackground=COR_BORDA,
            highlightthickness=1
        )
        return card

    def dashboard_card(self, parent, titulo, valor, subtitulo="", cor=COR_VERMELHO):
        caixa = tk.Frame(parent, bg=COR_BRANCO, padx=22, pady=18, highlightbackground=COR_BORDA, highlightthickness=1)
        tk.Label(caixa, text=titulo, bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 10, "bold")).pack(anchor="w")
        tk.Label(caixa, text=str(valor), bg=COR_BRANCO, fg=cor, font=("Arial", 24, "bold")).pack(anchor="w", pady=(6, 0))
        if subtitulo:
            tk.Label(caixa, text=subtitulo, bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 9)).pack(anchor="w")
        return caixa

    def titulo_secao(self, parent, titulo, subtitulo=None):
        tk.Label(parent, text=titulo, bg=COR_FUNDO, fg=COR_PRETO_TEXTO, font=("Arial", 22, "bold")).pack(anchor="w")
        if subtitulo:
            tk.Label(parent, text=subtitulo, bg=COR_FUNDO, fg=COR_CINZA, font=("Arial", 11)).pack(anchor="w", pady=(6, 18))

    def mostrar_mensagem(self, titulo, texto, tipo="info", ao_fechar=None):
        janela = tk.Toplevel(self.root)
        janela.title(titulo)
        janela.geometry("460x245")
        janela.configure(bg=COR_BRANCO)
        janela.resizable(False, False)
        janela.grab_set()
        cor = COR_VERDE if tipo == "sucesso" else COR_ERRO if tipo == "erro" else COR_VERMELHO
        simbolo = "✓" if tipo == "sucesso" else "✕" if tipo == "erro" else "!"
        tk.Label(janela, text=simbolo, bg=COR_BRANCO, fg=cor, font=("Arial", 42, "bold")).pack(pady=(18, 4))
        tk.Label(janela, text=titulo, bg=COR_BRANCO, fg=cor, font=("Arial", 16, "bold")).pack()
        tk.Label(janela, text=texto, bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 11), wraplength=380, justify="center").pack(pady=12)
        def fechar():
            janela.destroy()
            if ao_fechar:
                ao_fechar()
        BotaoAnimado(janela, "OK", fechar, largura=14, cor=cor).pack(pady=5)

    def carregar_imagem(self, caminho, tamanho=(260, 170)):
        if not caminho:
            return None
        try:
            img = Image.open(caminho)
            img = img.convert("RGB")
            img.thumbnail(tamanho, Image.LANCZOS)
            fundo = Image.new("RGB", tamanho, "white")
            x = (tamanho[0] - img.width) // 2
            y = (tamanho[1] - img.height) // 2
            fundo.paste(img, (x, y))
            foto = ImageTk.PhotoImage(fundo)
            self.imagens_tk.append(foto)
            return foto
        except Exception:
            return None

    def carregar_imagem_preencher(self, caminho, tamanho=(420, 420)):
        """Carrega a imagem preenchendo todo o espaço, cortando apenas o excesso."""
        if not caminho:
            return None
        try:
            img = Image.open(caminho).convert("RGB")
            alvo_w, alvo_h = tamanho
            escala = max(alvo_w / img.width, alvo_h / img.height)
            novo_w = int(img.width * escala)
            novo_h = int(img.height * escala)
            img = img.resize((novo_w, novo_h), Image.LANCZOS)
            esquerda = max((novo_w - alvo_w) // 2, 0)
            topo = max((novo_h - alvo_h) // 2, 0)
            img = img.crop((esquerda, topo, esquerda + alvo_w, topo + alvo_h))
            foto = ImageTk.PhotoImage(img)
            self.imagens_tk.append(foto)
            return foto
        except Exception:
            return None

    def tela_inicial(self):
        self.limpar()
        self.cabecalho("Química Experimental")

        conteudo = tk.Frame(self.root, bg=COR_FUNDO)
        conteudo.pack(expand=True, fill="both", padx=self.medida_ui(36), pady=self.medida_ui(20))

        centro = tk.Frame(conteudo, bg=COR_FUNDO)
        centro.place(relx=0.5, rely=0.45, anchor="center")

        tk.Label(
            centro,
            text="Jogo Educacional de Materiais de Laboratório",
            bg=COR_FUNDO,
            fg=COR_VERMELHO,
            font=self.fonte_ui(30, True)
        ).pack(pady=(0, self.medida_ui(14)))

        tk.Label(
            centro,
            text="Identifique materiais, funções e sistemas experimentais por meio de perguntas com imagens.",
            bg=COR_FUNDO,
            fg=COR_CINZA,
            font=self.fonte_ui(14),
            wraplength=self.medida_ui(980),
            justify="center"
        ).pack(pady=(0, self.medida_ui(34)))

        card = self.card(centro, self.medida_ui(52), self.medida_ui(38))
        card.pack()
        BotaoAnimado(card, "Entrar", self.tela_login, largura=34).pack(pady=self.medida_ui(8), ipady=self.medida_ui(3))
        BotaoAnimado(card, "Sair", self.root.destroy, largura=34, cor="#777777").pack(pady=self.medida_ui(8), ipady=self.medida_ui(3))

        tk.Label(
            conteudo,
            bg=COR_FUNDO,
            fg=COR_CINZA,
            font=self.fonte_ui(10)
        ).pack(side="bottom", pady=self.medida_ui(18))

    def campo(self, parent, texto, show=None):
        tk.Label(parent, text=texto, bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 11, "bold")).pack(anchor="w", pady=(8, 2))
        entrada = ttk.Entry(parent, show=show, width=44); entrada.pack(fill="x")
        return entrada

    def tela_login(self):
        self.limpar(); self.cabecalho("Acesso ao Sistema")
        card = self.card(self.root, self.medida_ui(48), self.medida_ui(38)); card.pack(expand=True)
        tk.Label(card, text="Entrar na plataforma", bg=COR_BRANCO, fg=COR_VERMELHO, font=self.fonte_ui(24, True)).pack(pady=(0, self.medida_ui(12)))
        email = self.campo(card, "E-mail"); senha = self.campo(card, "Senha", show="*")
        def entrar():
            conn = conectar()
            user = conn.execute("SELECT * FROM usuarios WHERE email=? AND ativo=1", (email.get().strip().lower(),)).fetchone()
            conn.close()
            if user and user["senha_hash"] == hash_senha(senha.get()):
                self.usuario = dict(user)
                self.tela_professor() if user["tipo_usuario"] == "professor" else self.tela_menu_aluno()
            else:
                self.mostrar_mensagem("Acesso negado", "E-mail ou senha inválidos.", "erro")
        BotaoAnimado(card, "Entrar", entrar, largura=30).pack(pady=(20, 8))
        BotaoAnimado(card, "Voltar", self.tela_inicial, largura=30, cor=COR_CINZA).pack(pady=6)

    def tela_cadastro(self):
        if not self.usuario or self.usuario.get("tipo_usuario") != "professor":
            self.mostrar_mensagem("Acesso restrito", "Apenas professores podem cadastrar usuários.", "erro", self.tela_login)
            return
        self.limpar(); self.cabecalho("Cadastro de Usuário")
        card = self.card(self.root, 35, 25); card.pack(pady=35)
        tk.Label(card, text="Criar novo usuário", bg=COR_BRANCO, fg=COR_VERMELHO, font=("Arial", 20, "bold")).pack(pady=8)
        nome = self.campo(card, "Nome"); email = self.campo(card, "E-mail"); senha = self.campo(card, "Senha", show="*")
        tk.Label(card, text="Tipo de usuário", bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 11, "bold")).pack(anchor="w", pady=(8, 2))
        tipo = ttk.Combobox(card, values=["aluno", "professor"], state="readonly"); tipo.set("aluno"); tipo.pack(fill="x")
        def cadastrar():
            if not nome.get() or not email.get() or not senha.get():
                self.mostrar_mensagem("Campos obrigatórios", "Preencha todos os campos antes de continuar.", "info"); return
            email_digitado = email.get().strip().lower()
            tipo_usuario = tipo.get()

            if tipo_usuario == "aluno" and not email_digitado.endswith("@aluno.cps.sp.gov.br"):
                self.mostrar_mensagem("E-mail inválido", "O login do aluno deve seguir o padrão: xxxxxx@aluno.cps.sp.gov.br", "erro")
                return

            if tipo_usuario == "professor" and not email_digitado.endswith("@cps.sp.gov.br"):
                self.mostrar_mensagem("E-mail inválido", "O login do professor deve seguir o padrão: xxxxxx@cps.sp.gov.br", "erro")
                return

            try:
                conn = conectar()
                id_turma = 1 if tipo.get() == "aluno" else None
                conn.execute("INSERT INTO usuarios (nome,email,senha_hash,tipo_usuario,id_turma) VALUES (?,?,?,?,?)", (nome.get(), email_digitado, hash_senha(senha.get()), tipo_usuario, id_turma))
                conn.commit(); conn.close()
                self.mostrar_mensagem("Cadastro realizado", "Usuário cadastrado com sucesso.", "sucesso", self.tela_professor)
            except pymysql.err.IntegrityError:
                self.mostrar_mensagem("E-mail já cadastrado", "Use outro e-mail para realizar o cadastro.", "erro")
        BotaoAnimado(card, "Cadastrar", cadastrar, largura=30).pack(pady=(18, 8))
        BotaoAnimado(card, "Voltar", self.tela_professor, largura=30, cor=COR_CINZA).pack(pady=6)

    def tela_menu_aluno(self):
        self.limpar(); self.cabecalho("Área do Aluno")
        conteudo = tk.Frame(self.root, bg=COR_FUNDO)
        conteudo.pack(expand=True, fill="both", padx=46, pady=30)

        self.titulo_secao(
            conteudo,
            f"Olá, {self.usuario['nome']}!",
            "Acompanhe seu desempenho e escolha quando iniciar uma nova partida."
        )

        conn = conectar()
        dados = conn.execute("""
            SELECT
                COUNT(*) AS partidas,
                COALESCE(MAX(pontuacao_total), 0) AS melhor,
                COALESCE(SUM(quantidade_acertos), 0) AS acertos,
                COALESCE(SUM(total_perguntas), 0) AS total
            FROM partidas
            WHERE id_aluno=? AND status_partida='finalizada'
        """, (self.usuario["id_usuario"],)).fetchone()
        perguntas = conn.execute("SELECT COUNT(*) AS total FROM perguntas WHERE ativa=1").fetchone()["total"]
        conn.close()
        aproveitamento = round((dados["acertos"] / dados["total"]) * 100, 1) if dados["total"] else 0

        cards = tk.Frame(conteudo, bg=COR_FUNDO)
        cards.pack(fill="x", pady=(0, 24))
        for col in range(4):
            cards.grid_columnconfigure(col, weight=1, uniform="cards")
        self.dashboard_card(cards, "Partidas finalizadas", dados["partidas"], "histórico do aluno").grid(row=0, column=0, sticky="ew", padx=(0, 12))
        self.dashboard_card(cards, "Melhor pontuação", dados["melhor"], "recorde pessoal").grid(row=0, column=1, sticky="ew", padx=12)
        self.dashboard_card(cards, "Aproveitamento", f"{aproveitamento}%", "média geral", COR_VERDE).grid(row=0, column=2, sticky="ew", padx=12)
        self.dashboard_card(cards, "Questões disponíveis", perguntas, "banco ativo", COR_CINZA).grid(row=0, column=3, sticky="ew", padx=(12, 0))

        principal = tk.Frame(conteudo, bg=COR_FUNDO)
        principal.pack(fill="both", expand=True)
        principal.grid_columnconfigure(0, weight=2)
        principal.grid_columnconfigure(1, weight=1)
        principal.grid_rowconfigure(0, weight=1)

        painel_jogo = self.card(principal, 34, 30)
        painel_jogo.grid(row=0, column=0, sticky="nsew", padx=(0, 16))
        tk.Label(painel_jogo, text="Pronto para jogar?", bg=COR_BRANCO, fg=COR_PRETO_TEXTO, font=("Arial", 21, "bold")).pack(anchor="w")
        tk.Label(
            painel_jogo,
            text="Responda às questões, use a dica quando precisar e veja seu resultado ao final. O objetivo é aprender os materiais e sistemas de laboratório.",
            bg=COR_BRANCO,
            fg=COR_CINZA,
            font=("Arial", 12),
            wraplength=680,
            justify="left"
        ).pack(anchor="w", pady=(10, 24))

        modos = tk.Frame(painel_jogo, bg=COR_BRANCO)
        modos.pack(fill="x", pady=(0, 20))
        for texto, desc in [("Fácil", "materiais básicos"), ("Médio", "funções e usos"), ("Difícil", "sistemas experimentais")]:
            box = tk.Frame(modos, bg="#F8FAFC", padx=16, pady=14, highlightbackground=COR_BORDA, highlightthickness=1)
            box.pack(side="left", fill="x", expand=True, padx=6)
            tk.Label(box, text=texto, bg="#F8FAFC", fg=COR_VERMELHO, font=("Arial", 14, "bold")).pack(anchor="w")
            tk.Label(box, text=desc, bg="#F8FAFC", fg=COR_CINZA, font=("Arial", 9)).pack(anchor="w")

        BotaoAnimado(painel_jogo, "Iniciar jogo", self.iniciar_jogo, largura=34).pack(anchor="w", pady=(8, 8))
        BotaoAnimado(painel_jogo, "Sair", self.tela_inicial, largura=34, cor=COR_CINZA).pack(anchor="w")

        painel_dicas = self.card(principal, 26, 26)
        painel_dicas.grid(row=0, column=1, sticky="nsew")
        tk.Label(painel_dicas, text="Como funciona", bg=COR_BRANCO, fg=COR_PRETO_TEXTO, font=("Arial", 17, "bold")).pack(anchor="w")
        for item in ["Leia o enunciado com atenção.", "Clique na alternativa escolhida.", "Use a dica para eliminar uma opção incorreta.", "Confira sua pontuação no final."]:
            tk.Label(painel_dicas, text=f"• {item}", bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 11), justify="left").pack(anchor="w", pady=7)

    def iniciar_jogo(self):
        conn = conectar()
        self.questoes = conn.execute("SELECT * FROM perguntas WHERE ativa=1 ORDER BY id_modo, id_pergunta").fetchall()
        if not self.questoes:
            conn.close(); self.mostrar_mensagem("Sem perguntas", "Nenhuma pergunta cadastrada.", "info"); return
        conn.execute("INSERT INTO partidas (id_aluno,id_modo,total_perguntas) VALUES (?,?,?)", (self.usuario["id_usuario"], self.questoes[0]["id_modo"], len(self.questoes)))
        self.partida_id = conn.lastrowid
        conn.commit(); conn.close()
        self.indice = 0; self.pontos = 0; self.acertos = 0; self.erros = 0; self.resposta_id = None
        self.tela_questao()

    def selecionar_alternativa(self, id_alt):
        self.resposta_id = id_alt
        for aid, widget in self.alternativa_widgets.items():
            widget.config(bg=COR_DESTAQUE if aid == id_alt else COR_BRANCO, highlightbackground=COR_VERMELHO if aid == id_alt else COR_BORDA, highlightthickness=2 if aid == id_alt else 1)

    def tela_questao(self):
        self.limpar()
        self.cabecalho("")

        if self.indice >= len(self.questoes):
            self.finalizar_jogo()
            return

        q = self.questoes[self.indice]
        tipo_questao = q["tipo_pergunta"]
        self.resposta_id = None
        self.alternativa_widgets = {}

        conn = conectar()
        alternativas = conn.execute(
            "SELECT * FROM alternativas WHERE id_pergunta=? ORDER BY ordem",
            (q["id_pergunta"],)
        ).fetchall()
        dica = conn.execute(
            "SELECT texto_dica FROM dicas WHERE id_pergunta=? LIMIT 1",
            (q["id_pergunta"],)
        ).fetchone()
        conn.close()

        pagina = tk.Frame(self.root, bg=COR_FUNDO)
        pagina.pack(expand=True, fill="both")

        faixa = tk.Frame(pagina, bg=COR_FUNDO, height=self.medida_ui(58))
        faixa.pack(fill="x", padx=self.medida_ui(24), pady=(self.medida_ui(10), 0))
        faixa.pack_propagate(False)

        icone = tk.Canvas(faixa, width=self.medida_ui(44), height=self.medida_ui(44), bg=COR_FUNDO, highlightthickness=0)
        icone.pack(side="left", padx=(0, self.medida_ui(14)))
        icone.create_oval(self.medida_ui(3), self.medida_ui(3), self.medida_ui(41), self.medida_ui(41), fill=COR_VERMELHO, outline=COR_VERMELHO)
        icone.create_text(self.medida_ui(22), self.medida_ui(23), text="⚗", fill="white", font=self.fonte_ui(18, True))

        tk.Label(
            faixa,
            text="Jogo - Materiais de Laboratório",
            bg=COR_FUNDO,
            fg=COR_PRETO_TEXTO,
            font=self.fonte_ui(21, True)
        ).pack(side="left")

        status = tk.Frame(faixa, bg=COR_FUNDO)
        status.pack(side="right")
        tk.Label(
            status,
            text=f"❔  Questão {self.indice + 1}/{len(self.questoes)}   │   ★  Pontos: {self.pontos}   │   🏆  Valor: {q['pontuacao']} pontos",
            bg=COR_FUNDO,
            fg=COR_CINZA,
            font=self.fonte_ui(11, True)
        ).pack(pady=self.medida_ui(12))

        card = tk.Frame(
            pagina,
            bg=COR_BRANCO,
            padx=self.medida_ui(20),
            pady=self.medida_ui(16),
            highlightbackground=COR_BORDA,
            highlightthickness=1
        )
        card.pack(fill="both", expand=True, padx=self.medida_ui(24), pady=(self.medida_ui(6), self.medida_ui(10)))

        texto_enunciado_tela = q["enunciado"]
        if tipo_questao == "identificacao":
            nome_material_tela = q["resposta_correta_texto"] or "material informado"
            texto_enunciado_tela = f"Qual das imagens representa o material: {nome_material_tela}?"

        tk.Label(
            card,
            text=texto_enunciado_tela,
            bg=COR_BRANCO,
            fg=COR_PRETO_TEXTO,
            font=self.fonte_ui(17, True),
            wraplength=self.medida_ui(1300),
            justify="left"
        ).pack(anchor="w", pady=(0, self.medida_ui(10)))

        area = tk.Frame(card, bg=COR_BRANCO)
        area.pack(fill="both", expand=True)

        def clicar_alt(event=None, aid=None):
            if aid is not None:
                self.selecionar_alternativa(aid)

        # Layout para perguntas do tipo identificação:
        # mostra SOMENTE o nome do material no enunciado e as 4 imagens nas alternativas.
        # Não exibe o nome das alternativas para não entregar a resposta.
        if tipo_questao == "identificacao":
            for col in range(2):
                area.grid_columnconfigure(col, weight=1, uniform="alternativas")
            for row in range(2):
                area.grid_rowconfigure(row, weight=1, uniform="alternativas")

            for idx, alt in enumerate(alternativas[:4]):
                row = idx // 2
                col = idx % 2
                letra = chr(97 + idx)

                caixa = tk.Frame(
                    area,
                    bg=COR_BRANCO,
                    padx=self.medida_ui(12),
                    pady=self.medida_ui(8),
                    highlightbackground=COR_BORDA,
                    highlightthickness=1,
                    cursor="hand2"
                )
                caixa.grid(
                    row=row,
                    column=col,
                    sticky="nsew",
                    padx=self.medida_ui(8),
                    pady=self.medida_ui(6)
                )

                tk.Label(
                    caixa,
                    text=f"{letra})",
                    bg=COR_BRANCO,
                    fg=COR_PRETO_TEXTO,
                    font=self.fonte_ui(18, True),
                    anchor="w"
                ).pack(anchor="w")

                # Tamanho menor para caber corretamente em notebook/Full HD.
                foto_alt = self.carregar_imagem(
                    alt["imagem_url"],
                    (self.medida_ui(330), self.medida_ui(190))
                )
                if foto_alt:
                    img_label = tk.Label(caixa, image=foto_alt, bg=COR_BRANCO, cursor="hand2")
                    img_label.pack(expand=True, pady=(self.medida_ui(2), self.medida_ui(2)))
                    img_label.bind("<Button-1>", lambda e, aid=alt["id_alternativa"]: clicar_alt(e, aid))
                else:
                    tk.Label(
                        caixa,
                        text="Imagem não cadastrada",
                        bg=COR_BRANCO,
                        fg=COR_ERRO,
                        font=self.fonte_ui(13, True),
                        justify="center"
                    ).pack(expand=True)

                caixa.bind("<Button-1>", lambda e, aid=alt["id_alternativa"]: clicar_alt(e, aid))
                self.alternativa_widgets[alt["id_alternativa"]] = caixa

        else:
            # Múltipla escolha e associação continuam em lista, sem imagem nas alternativas.
            foto_pergunta = self.carregar_imagem_preencher(q["imagem_url"], (340, 430))
            if foto_pergunta:
                frame_img = tk.Frame(
                    area,
                    bg=COR_BRANCO,
                    highlightbackground=COR_BORDA,
                    highlightthickness=1,
                    width=340,
                    height=430
                )
                frame_img.pack(side="left", fill="y", padx=(0, 32), anchor="n")
                frame_img.pack_propagate(False)
                tk.Label(frame_img, image=foto_pergunta, bg=COR_BRANCO).pack(fill="both", expand=True)

            frame_alt = tk.Frame(area, bg=COR_BRANCO)
            frame_alt.pack(side="right" if foto_pergunta else "left", fill="both", expand=True, padx=(20, 0))

            for alt in alternativas:
                caixa = tk.Frame(
                    frame_alt,
                    bg=COR_BRANCO,
                    padx=18,
                    pady=14,
                    highlightbackground=COR_BORDA,
                    highlightthickness=1,
                    cursor="hand2"
                )
                caixa.pack(fill="x", pady=8, anchor="w")

                letra = chr(96 + alt["ordem"])
                texto_alt = tk.Label(
                    caixa,
                    text=f"{letra}) {alt['texto'] or ''}",
                    bg=COR_BRANCO,
                    fg=COR_PRETO_TEXTO,
                    font=("Arial", 28, "bold"),
                    anchor="w",
                    justify="left"
                )
                texto_alt.pack(side="left", fill="x", expand=True)

                caixa.bind("<Button-1>", lambda e, aid=alt["id_alternativa"]: clicar_alt(e, aid))
                texto_alt.bind("<Button-1>", lambda e, aid=alt["id_alternativa"]: clicar_alt(e, aid))
                self.alternativa_widgets[alt["id_alternativa"]] = caixa

        botoes = tk.Frame(card, bg=COR_BRANCO)
        botoes.pack(fill="x", pady=(self.medida_ui(8), 0))

        def usar_dica():
            if self.partida_id:
                conn = conectar()
                conn.execute(
                    "INSERT INTO ajudas_utilizadas (id_partida,id_pergunta,tipo_ajuda) VALUES (?,?,?)",
                    (self.partida_id, q["id_pergunta"], "dica")
                )
                conn.commit()
                conn.close()

            self.mostrar_mensagem(
                "Dica",
                dica["texto_dica"] if dica else "Sem dica cadastrada.",
                "info"
            )

        BotaoAnimado(botoes, "💡  Dica", usar_dica, cor=COR_VERMELHO).pack(side="left", padx=5)
        BotaoAnimado(botoes, "✓  Responder", self.verificar_resposta).pack(side="right", padx=5)
        BotaoAnimado(botoes, "↪  Sair", self.tela_menu_aluno, cor=COR_CINZA).pack(side="right", padx=12)

    def verificar_resposta(self):
        if not self.resposta_id:
            self.mostrar_mensagem("Selecione uma alternativa", "Clique em uma das alternativas antes de responder.", "info"); return
        q = self.questoes[self.indice]
        conn = conectar()
        alt = conn.execute("SELECT * FROM alternativas WHERE id_alternativa=?", (self.resposta_id,)).fetchone()
        correta_alt = conn.execute("SELECT * FROM alternativas WHERE id_pergunta=? AND correta=1 LIMIT 1", (q["id_pergunta"],)).fetchone()
        correta = bool(alt["correta"])
        pontos = q["pontuacao"] if correta else 0
        conn.execute("INSERT INTO respostas_partida (id_partida,id_pergunta,id_alternativa,resposta_texto,correta,pontos_obtidos) VALUES (?,?,?,?,?,?)", (self.partida_id, q["id_pergunta"], self.resposta_id, alt["texto"], 1 if correta else 0, pontos))
        conn.commit(); conn.close()
        for aid, widget in self.alternativa_widgets.items():
            if correta_alt and aid == correta_alt["id_alternativa"]:
                widget.config(bg=COR_VERDE_CLARO, highlightbackground=COR_VERDE, highlightthickness=3)
            elif aid == self.resposta_id:
                widget.config(bg=COR_ERRO_CLARO, highlightbackground=COR_ERRO, highlightthickness=3)
        if correta:
            self.pontos += pontos; self.acertos += 1
            self.root.after(700, lambda: self.mostrar_mensagem("Resposta correta", "Muito bem! Você acertou a questão.", "sucesso", self.proxima_questao))
        else:
            self.erros += 1
            texto = f"A alternativa correta era: {correta_alt['texto']}" if correta_alt else "A resposta estava incorreta."
            self.root.after(700, lambda: self.mostrar_mensagem("Resposta incorreta", texto, "erro", self.proxima_questao))

    def proxima_questao(self):
        self.indice += 1
        self.tela_questao()

    def finalizar_jogo(self):
        conn = conectar()
        conn.execute("""
            UPDATE partidas SET pontuacao_total=?, quantidade_acertos=?, quantidade_erros=?, total_perguntas=?, data_fim=?, status_partida='finalizada'
            WHERE id_partida=?
        """, (self.pontos, self.acertos, self.erros, len(self.questoes), datetime.now().strftime("%Y-%m-%d %H:%M:%S"), self.partida_id))
        conn.commit(); conn.close()
        total = len(self.questoes); percentual = round((self.acertos/total)*100, 1) if total else 0
        self.limpar(); self.cabecalho("Resultado")
        card = self.card(self.root, 45, 35); card.pack(pady=80)
        tk.Label(card, text="Partida finalizada!", bg=COR_BRANCO, fg=COR_VERMELHO, font=("Arial", 25, "bold")).pack(pady=10)
        tk.Label(card, text=f"Pontuação: {self.pontos} pontos", bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 18)).pack(pady=8)
        tk.Label(card, text=f"Acertos: {self.acertos}/{total}  •  Aproveitamento: {percentual}%", bg=COR_BRANCO, fg=COR_VERDE, font=("Arial", 16, "bold")).pack(pady=8)
        BotaoAnimado(card, "Jogar novamente", self.iniciar_jogo, largura=30).pack(pady=8)
        BotaoAnimado(card, "Voltar ao menu", self.tela_menu_aluno, largura=30, cor=COR_CINZA).pack(pady=8)

    def tela_professor(self):
        self.limpar(); self.cabecalho("Área do Professor")
        conteudo = tk.Frame(self.root, bg=COR_FUNDO)
        conteudo.pack(expand=True, fill="both", padx=46, pady=30)
        self.titulo_secao(conteudo, f"Bem-vindo(a), {self.usuario['nome']}", "Gerencie perguntas, usuários, relatórios e ranking do jogo.")

        conn = conectar()
        total_perguntas = conn.execute("SELECT COUNT(*) AS total FROM perguntas").fetchone()["total"]
        perguntas_ativas = conn.execute("SELECT COUNT(*) AS total FROM perguntas WHERE ativa=1").fetchone()["total"]
        total_alunos = conn.execute("SELECT COUNT(*) AS total FROM usuarios WHERE tipo_usuario='aluno' AND ativo=1").fetchone()["total"]
        partidas = conn.execute("SELECT COUNT(*) AS total FROM partidas WHERE status_partida='finalizada'").fetchone()["total"]
        conn.close()

        cards = tk.Frame(conteudo, bg=COR_FUNDO)
        cards.pack(fill="x", pady=(0, 24))
        for col in range(4):
            cards.grid_columnconfigure(col, weight=1, uniform="cards")
        self.dashboard_card(cards, "Perguntas", total_perguntas, f"{perguntas_ativas} ativas").grid(row=0, column=0, sticky="ew", padx=(0, 12))
        self.dashboard_card(cards, "Alunos ativos", total_alunos, "usuários cadastrados", COR_CINZA).grid(row=0, column=1, sticky="ew", padx=12)
        self.dashboard_card(cards, "Partidas", partidas, "finalizadas", COR_VERDE).grid(row=0, column=2, sticky="ew", padx=12)
        self.dashboard_card(cards, "Status", "OK", "sistema disponível", COR_VERDE).grid(row=0, column=3, sticky="ew", padx=(12, 0))

        painel = self.card(conteudo, 28, 26)
        painel.pack(fill="both", expand=True)
        tk.Label(painel, text="Ações rápidas", bg=COR_BRANCO, fg=COR_PRETO_TEXTO, font=("Arial", 18, "bold")).pack(anchor="w", pady=(0, 16))

        grid = tk.Frame(painel, bg=COR_BRANCO)
        grid.pack(fill="x")
        acoes = [
            ("Cadastrar nova pergunta", "Adicionar questão ao banco", self.tela_nova_questao, COR_VERMELHO),
            ("Banco de questões", "Visualizar, filtrar e remover", self.tela_listar_questoes, COR_CINZA),
            ("Cadastrar usuário", "Criar aluno ou professor", self.tela_cadastro, COR_CINZA),
            ("Usuários", "Consultar cadastros", self.tela_usuarios, COR_CINZA),
            ("Relatórios", "Ver desempenho dos alunos", self.tela_relatorios, COR_CINZA),
            ("Ranking geral", "Melhores pontuações", self.tela_ranking, COR_CINZA),
        ]
        for i, (titulo, desc, cmd, cor) in enumerate(acoes):
            box = tk.Frame(grid, bg="#F8FAFC", padx=18, pady=18, highlightbackground=COR_BORDA, highlightthickness=1)
            box.grid(row=i//3, column=i%3, sticky="ew", padx=8, pady=8)
            tk.Label(box, text=titulo, bg="#F8FAFC", fg=COR_PRETO_TEXTO, font=("Arial", 13, "bold")).pack(anchor="w")
            tk.Label(box, text=desc, bg="#F8FAFC", fg=COR_CINZA, font=("Arial", 10)).pack(anchor="w", pady=(4, 12))
            BotaoAnimado(box, "Abrir", cmd, largura=18, cor=cor).pack(anchor="w")
        for col in range(3):
            grid.grid_columnconfigure(col, weight=1, uniform="acoes")

        BotaoAnimado(painel, "Sair", self.tela_inicial, largura=20, cor="#777777").pack(anchor="e", pady=(20, 0))

    def tela_nova_questao(self):
        self.limpar()
        self.cabecalho("Cadastrar Pergunta")

        frame = self.card(self.root, 28, 14)
        frame.pack(fill="both", expand=True, padx=35, pady=20)

        def label(t):
            tk.Label(
                frame,
                text=t,
                bg=COR_BRANCO,
                fg=COR_CINZA,
                font=("Arial", 10, "bold")
            ).pack(anchor="w", pady=(4, 1))

        label("Enunciado")
        enunciado = tk.Text(frame, height=3, font=("Arial", 10))
        enunciado.pack(fill="x")

        caminho_pergunta = tk.StringVar(value="")

        def escolher_pergunta():
            caminho = filedialog.askopenfilename(filetypes=[("Imagens", "*.png *.jpg *.jpeg")])
            caminho_pergunta.set(self.copiar_imagem(caminho) or "")

        BotaoAnimado(
            frame,
            "Selecionar imagem da pergunta/opcional",
            escolher_pergunta,
            cor=COR_CINZA
        ).pack(anchor="w", pady=5)

        linha_tipo = tk.Frame(frame, bg=COR_BRANCO)
        linha_tipo.pack(fill="x", pady=8)

        correta = ttk.Combobox(linha_tipo, values=["1", "2", "3", "4"], state="readonly", width=10)
        correta.set("1")

        modo = ttk.Combobox(linha_tipo, values=["Fácil", "Médio", "Difícil"], state="readonly", width=15)
        modo.set("Fácil")

        tipo = ttk.Combobox(
            linha_tipo,
            values=["identificacao", "multipla_escolha", "associacao"],
            state="readonly",
            width=20
        )
        tipo.set("multipla_escolha")

        for txt, wid in [("Correta", correta), ("Modo", modo), ("Tipo", tipo)]:
            tk.Label(
                linha_tipo,
                text=txt,
                bg=COR_BRANCO,
                fg=COR_CINZA,
                font=("Arial", 10, "bold")
            ).pack(side="left", padx=(8, 2))
            wid.pack(side="left")

        aviso_tipo = tk.Label(
            frame,
            text="Múltipla escolha: imagem somente no enunciado. Identificação: permite imagem nas alternativas.",
            bg=COR_BRANCO,
            fg=COR_CINZA,
            font=("Arial", 10, "bold")
        )
        aviso_tipo.pack(anchor="w", pady=(4, 6))

        alternativas_area = tk.Frame(frame, bg=COR_BRANCO)
        alternativas_area.pack(fill="both", expand=True, pady=4)

        entradas = []

        def montar_alternativas(event=None):
            for w in alternativas_area.winfo_children():
                w.destroy()
            entradas.clear()

            if tipo.get() == "identificacao":
                alternativas_area.grid_columnconfigure(0, weight=1, uniform="alt")
                alternativas_area.grid_columnconfigure(1, weight=1, uniform="alt")
                alternativas_area.grid_rowconfigure(0, weight=1, uniform="alt")
                alternativas_area.grid_rowconfigure(1, weight=1, uniform="alt")

                for i in range(1, 5):
                    idx = i - 1
                    row = idx // 2
                    col = idx % 2
                    caixa = tk.Frame(
                        alternativas_area,
                        bg=COR_BRANCO,
                        padx=12,
                        pady=10,
                        highlightbackground=COR_BORDA,
                        highlightthickness=1,
                        height=150
                    )
                    caixa.grid(row=row, column=col, sticky="nsew", padx=8, pady=8)

                    tk.Label(
                        caixa,
                        text=f"Alternativa {i}",
                        bg=COR_BRANCO,
                        fg=COR_CINZA,
                        font=("Arial", 10, "bold")
                    ).pack(anchor="w")

                    texto = ttk.Entry(caixa)
                    texto.pack(fill="x", pady=(4, 6))

                    img_var = tk.StringVar(value="")
                    status_img = tk.Label(
                        caixa,
                        text="Nenhuma imagem selecionada",
                        bg=COR_BRANCO,
                        fg=COR_CINZA,
                        font=("Arial", 9)
                    )
                    status_img.pack(anchor="w", pady=(0, 4))

                    def escolher(v=img_var, lbl=status_img):
                        caminho = filedialog.askopenfilename(filetypes=[("Imagens", "*.png *.jpg *.jpeg")])
                        novo = self.copiar_imagem(caminho)
                        if novo:
                            v.set(novo)
                            lbl.config(text="Imagem selecionada")

                    BotaoAnimado(caixa, "Imagem da alternativa", escolher, cor=COR_CINZA).pack(anchor="w")
                    entradas.append((texto, img_var))
            else:
                for i in range(1, 5):
                    linha = tk.Frame(alternativas_area, bg=COR_BRANCO)
                    linha.pack(fill="x", pady=6)

                    tk.Label(
                        linha,
                        text=f"Alternativa {i}",
                        bg=COR_BRANCO,
                        fg=COR_CINZA,
                        font=("Arial", 10, "bold"),
                        width=12
                    ).pack(side="left")

                    texto = ttk.Entry(linha)
                    texto.pack(side="left", fill="x", expand=True, padx=5)

                    # No tipo multipla_escolha/associacao, não existe botão de imagem nas alternativas.
                    entradas.append((texto, tk.StringVar(value="")))

        tipo.bind("<<ComboboxSelected>>", montar_alternativas)
        montar_alternativas()

        label("Dica")
        dica = ttk.Entry(frame)
        dica.pack(fill="x")

        def salvar():
            texto_enunciado = enunciado.get("1.0", "end").strip()

            if len(entradas) != 4:
                self.mostrar_mensagem("Atenção", "As 4 alternativas precisam estar preenchidas.", "info")
                return

            idx_correta = int(correta.get())
            resposta_correta = entradas[idx_correta - 1][0].get().strip()

            if tipo.get() == "identificacao":
                if not resposta_correta:
                    self.mostrar_mensagem("Atenção", "Informe o nome do material na alternativa correta.", "info")
                    return
                texto_enunciado = f"Qual das imagens representa o material: {resposta_correta}?"
                for txt, img in entradas:
                    if not txt.get().strip() or not img.get():
                        self.mostrar_mensagem(
                            "Atenção",
                            "No tipo identificação, preencha o nome e selecione a imagem das 4 alternativas.",
                            "info"
                        )
                        return
            else:
                if not texto_enunciado:
                    self.mostrar_mensagem("Atenção", "Informe o enunciado.", "info")
                    return
                for txt, _img in entradas:
                    if not txt.get().strip():
                        self.mostrar_mensagem(
                            "Atenção",
                            "No tipo múltipla escolha, preencha o texto de todas as alternativas.",
                            "info"
                        )
                        return

            conn = conectar()
            id_modo = {"Fácil": 1, "Médio": 2, "Difícil": 3}[modo.get()]
            conn.execute(
                """
                INSERT INTO perguntas
                (id_modo,id_professor_criador,enunciado,imagem_url,tipo_pergunta,resposta_correta_texto,pontuacao)
                VALUES (?,?,?,?,?,?,?)
                """,
                (
                    id_modo,
                    self.usuario["id_usuario"],
                    texto_enunciado,
                    "" if tipo.get() == "identificacao" else caminho_pergunta.get(),
                    tipo.get(),
                    resposta_correta,
                    10
                )
            )
            idp = conn.lastrowid

            for ordem, (txt, img) in enumerate(entradas, start=1):
                imagem_alternativa = img.get() if tipo.get() == "identificacao" else ""
                conn.execute(
                    """
                    INSERT INTO alternativas (id_pergunta,texto,imagem_url,correta,ordem)
                    VALUES (?,?,?,?,?)
                    """,
                    (
                        idp,
                        txt.get().strip(),
                        imagem_alternativa,
                        1 if ordem == idx_correta else 0,
                        ordem
                    )
                )

            if dica.get().strip():
                conn.execute(
                    "INSERT INTO dicas (id_pergunta,texto_dica) VALUES (?,?)",
                    (idp, dica.get().strip())
                )

            conn.commit()
            conn.close()
            self.mostrar_mensagem(
                "Pergunta cadastrada",
                "A pergunta foi salva corretamente no banco.",
                "sucesso",
                self.tela_listar_questoes
            )

        botoes = tk.Frame(frame, bg=COR_BRANCO)
        botoes.pack(fill="x", pady=10)
        BotaoAnimado(botoes, "Salvar", salvar).pack(side="right", padx=5)
        BotaoAnimado(botoes, "Voltar", self.tela_professor, cor=COR_CINZA).pack(side="right", padx=5)

    def copiar_imagem(self, origem):
        if not origem: return ""
        try:
            origem = Path(origem)
            destino = IMG_DIR / f"{datetime.now().strftime('%Y%m%d%H%M%S%f')}_{origem.name}"
            shutil.copy(origem, destino)
            return str(destino)
        except Exception:
            return ""

    def montar_tabela(self, parent, colunas, larguras):
        container = tk.Frame(parent, bg=COR_BRANCO, highlightbackground=COR_BORDA, highlightthickness=1)
        container.pack(fill="both", expand=True, pady=(8, 0))

        tabela = ttk.Treeview(
            container,
            columns=colunas,
            show="headings",
            style="Modern.Treeview",
            selectmode="browse"
        )
        scroll_y = ttk.Scrollbar(container, orient="vertical", command=tabela.yview)
        scroll_x = ttk.Scrollbar(container, orient="horizontal", command=tabela.xview)
        tabela.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)

        tabela.grid(row=0, column=0, sticky="nsew")
        scroll_y.grid(row=0, column=1, sticky="ns")
        scroll_x.grid(row=1, column=0, sticky="ew")
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        for c in colunas:
            titulo = c.replace("_", " ").capitalize()
            largura = larguras.get(c, 130)
            if c in ("id", "posição", "pontos", "acertos", "erros", "total", "status"):
                anchor = "center"
            else:
                anchor = "w"
            stretch = True if c in ("enunciado", "aluno", "nome", "email") else False
            tabela.heading(c, text=titulo, anchor=anchor)
            tabela.column(c, width=largura, minwidth=max(70, min(largura, 160)), anchor=anchor, stretch=stretch)

        tabela.tag_configure("par", background="#FFFFFF")
        tabela.tag_configure("impar", background="#F3F6FA")
        tabela.tag_configure("removida", background="#FFF1F1", foreground="#8A1C16")
        return tabela

    def tela_listar_questoes(self):
        self.limpar(); self.cabecalho("Banco de questões")
        frame = tk.Frame(self.root, bg=COR_FUNDO)
        frame.pack(fill="both", expand=True, padx=32, pady=22)

        topo = tk.Frame(frame, bg=COR_FUNDO)
        topo.pack(fill="x")
        self.titulo_secao(
            topo,
            "Banco de questões",
            "Use a busca e os filtros para localizar perguntas. Selecione uma linha e clique em remover para desativá-la do jogo."
        )

        resumo = tk.Frame(frame, bg=COR_FUNDO)
        resumo.pack(fill="x", pady=(0, 14))
        conn = conectar()
        total = conn.execute("SELECT COUNT(*) AS t FROM perguntas").fetchone()["t"]
        ativas = conn.execute("SELECT COUNT(*) AS t FROM perguntas WHERE ativa=1").fetchone()["t"]
        ident = conn.execute("SELECT COUNT(*) AS t FROM perguntas WHERE tipo_pergunta='identificacao'").fetchone()["t"]
        conn.close()
        resumo.grid_columnconfigure(0, weight=1)
        resumo.grid_columnconfigure(1, weight=1)
        resumo.grid_columnconfigure(2, weight=1)
        self.dashboard_card(resumo, "Total de questões", total, "cadastradas").grid(row=0, column=0, sticky="ew", padx=(0, 12))
        self.dashboard_card(resumo, "Questões ativas", ativas, "aparecem no jogo", COR_VERDE).grid(row=0, column=1, sticky="ew", padx=12)
        self.dashboard_card(resumo, "Modo identificação", ident, "com imagens nas alternativas", COR_CINZA).grid(row=0, column=2, sticky="ew", padx=(12, 0))

        filtros = tk.Frame(frame, bg=COR_BRANCO, padx=18, pady=14, highlightbackground=COR_BORDA, highlightthickness=1)
        filtros.pack(fill="x", pady=(0, 14))
        tk.Label(filtros, text="Buscar pergunta", bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 10, "bold")).grid(row=0, column=0, sticky="w")
        busca = ttk.Entry(filtros, width=46)
        busca.grid(row=1, column=0, sticky="ew", padx=(0, 12), pady=(4, 0))
        tk.Label(filtros, text="Modo", bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 10, "bold")).grid(row=0, column=1, sticky="w")
        filtro_modo = ttk.Combobox(filtros, values=["Todos", "Fácil", "Médio", "Difícil"], state="readonly", width=16)
        filtro_modo.set("Todos")
        filtro_modo.grid(row=1, column=1, padx=8, pady=(4, 0))
        tk.Label(filtros, text="Tipo", bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 10, "bold")).grid(row=0, column=2, sticky="w")
        filtro_tipo = ttk.Combobox(filtros, values=["Todos", "Identificação", "Múltipla escolha", "Associação"], state="readonly", width=18)
        filtro_tipo.set("Todos")
        filtro_tipo.grid(row=1, column=2, padx=8, pady=(4, 0))
        tk.Label(filtros, text="Status", bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 10, "bold")).grid(row=0, column=3, sticky="w")
        filtro_status = ttk.Combobox(filtros, values=["Todos", "Ativa", "Removida"], state="readonly", width=16)
        filtro_status.set("Todos")
        filtro_status.grid(row=1, column=3, padx=(8, 0), pady=(4, 0))
        filtros.grid_columnconfigure(0, weight=1)

        tabela_card = tk.Frame(frame, bg=COR_BRANCO, highlightbackground=COR_BORDA, highlightthickness=1)
        tabela_card.pack(fill="both", expand=True)

        colunas = [
            ("ID", 1, "center"),
            ("Modo", 2, "center"),
            ("Tipo", 3, "center"),
            ("Status", 2, "center"),
            ("Enunciado", 9, "w"),
            ("Resposta", 3, "w"),
        ]
        header = tk.Frame(tabela_card, bg=COR_PRETO_TEXTO)
        header.pack(fill="x")
        for i, (titulo, peso, anchor) in enumerate(colunas):
            header.grid_columnconfigure(i, weight=peso, uniform="questoes")
            tk.Label(
                header,
                text=titulo,
                bg=COR_PRETO_TEXTO,
                fg="white",
                font=("Arial", 11, "bold"),
                padx=12,
                pady=14,
                anchor=anchor,
                highlightbackground="#CBD5E1",
                highlightthickness=1
            ).grid(row=0, column=i, sticky="nsew")

        canvas = tk.Canvas(tabela_card, bg=COR_BRANCO, highlightthickness=0)
        scroll_y = ttk.Scrollbar(tabela_card, orient="vertical", command=canvas.yview)
        corpo = tk.Frame(canvas, bg=COR_BRANCO)
        janela = canvas.create_window((0, 0), window=corpo, anchor="nw")
        canvas.configure(yscrollcommand=scroll_y.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll_y.pack(side="right", fill="y")

        def ajustar_largura(event):
            canvas.itemconfigure(janela, width=event.width)
        canvas.bind("<Configure>", ajustar_largura)
        corpo.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        selecionado = {"id": None, "linha": None, "status": None}

        def pintar_linha(linha, cor):
            for child in linha.winfo_children():
                child.configure(bg=cor)
            linha.configure(bg=cor)

        def selecionar_linha(linha, id_pergunta, status):
            if selecionado["linha"] is not None and selecionado["linha"].winfo_exists():
                cor_antiga = selecionado["linha"]._cor_original
                pintar_linha(selecionado["linha"], cor_antiga)
            selecionado["id"] = id_pergunta
            selecionado["linha"] = linha
            selecionado["status"] = status
            pintar_linha(linha, "#FFE8E8")

        def criar_linha(valores, indice):
            cor = "#FFFFFF" if indice % 2 == 0 else "#F8FAFC"
            if valores[3] == "Removida":
                cor = "#FFF1F1"
            linha = tk.Frame(corpo, bg=cor, cursor="hand2")
            linha._cor_original = cor
            linha.pack(fill="x")
            for i, (texto, (_, peso, anchor)) in enumerate(zip(valores, colunas)):
                linha.grid_columnconfigure(i, weight=peso, uniform="questoes")
                lbl = tk.Label(
                    linha,
                    text=texto,
                    bg=cor,
                    fg=COR_PRETO_TEXTO if valores[3] != "Removida" else "#8A1C16",
                    font=("Arial", 10),
                    padx=12,
                    pady=12,
                    anchor=anchor,
                    justify="left" if anchor == "w" else "center",
                    wraplength=620 if i == 4 else 190,
                    highlightbackground="#CBD5E1",
                    highlightthickness=1
                )
                lbl.grid(row=0, column=i, sticky="nsew")
                lbl.bind("<Button-1>", lambda e, l=linha, idp=valores[0], st=valores[3]: selecionar_linha(l, idp, st))
            linha.bind("<Button-1>", lambda e, l=linha, idp=valores[0], st=valores[3]: selecionar_linha(l, idp, st))

        def carregar_perguntas(*_):
            termo = busca.get().strip().lower()
            modo_escolhido = filtro_modo.get()
            status_escolhido = filtro_status.get()
            tipo_escolhido = filtro_tipo.get()
            selecionado["id"] = None
            selecionado["linha"] = None
            selecionado["status"] = None
            for item in corpo.winfo_children():
                item.destroy()
            conn = conectar()
            linhas = list(conn.execute("""
                SELECT p.id_pergunta, m.nome_modo, p.tipo_pergunta, p.enunciado,
                       p.resposta_correta_texto, p.ativa
                FROM perguntas p
                JOIN modos_jogo m ON m.id_modo=p.id_modo
                ORDER BY p.ativa DESC, p.id_pergunta DESC
            """))
            conn.close()
            contador = 0
            for r in linhas:
                status = "Ativa" if r["ativa"] else "Removida"
                tipo_formatado = r["tipo_pergunta"].replace("_", " ").title()
                tipo_filtro = {"identificacao":"Identificação", "multipla_escolha":"Múltipla escolha", "associacao":"Associação"}.get(r["tipo_pergunta"], tipo_formatado)
                texto_busca = f"{r['enunciado']} {r['resposta_correta_texto'] or ''}".lower()
                if termo and termo not in texto_busca:
                    continue
                if modo_escolhido != "Todos" and r["nome_modo"] != modo_escolhido:
                    continue
                if status_escolhido != "Todos" and status != status_escolhido:
                    continue
                if tipo_escolhido != "Todos" and tipo_escolhido != tipo_filtro:
                    continue
                criar_linha((r["id_pergunta"], r["nome_modo"], tipo_filtro, status, r["enunciado"], r["resposta_correta_texto"] or "-"), contador)
                contador += 1
            if contador == 0:
                vazio = tk.Label(corpo, text="Nenhuma pergunta encontrada com os filtros atuais.", bg=COR_BRANCO, fg=COR_CINZA, font=("Arial", 12), pady=30)
                vazio.pack(fill="x")

        def remover_pergunta():
            if not selecionado["id"]:
                self.mostrar_mensagem("Selecione uma pergunta", "Clique em uma linha da tabela antes de remover.", "info")
                return
            if selecionado["status"] == "Removida":
                self.mostrar_mensagem("Pergunta já removida", "Esta pergunta já está desativada e não aparecerá no jogo.", "info")
                return
            conn = conectar()
            conn.execute("UPDATE perguntas SET ativa=0 WHERE id_pergunta=?", (selecionado["id"],))
            conn.commit(); conn.close()
            carregar_perguntas()
            self.mostrar_mensagem("Pergunta removida", "A pergunta foi desativada e não aparecerá mais para os alunos.", "sucesso")

        busca.bind("<KeyRelease>", carregar_perguntas)
        filtro_modo.bind("<<ComboboxSelected>>", carregar_perguntas)
        filtro_tipo.bind("<<ComboboxSelected>>", carregar_perguntas)
        filtro_status.bind("<<ComboboxSelected>>", carregar_perguntas)
        carregar_perguntas()

        botoes = tk.Frame(frame, bg=COR_FUNDO)
        botoes.pack(fill="x", pady=14)
        BotaoAnimado(botoes, "Remover pergunta selecionada", remover_pergunta, cor=COR_ERRO).pack(side="left")
        BotaoAnimado(botoes, "Voltar", self.tela_professor, cor=COR_CINZA).pack(side="right")

    def tela_usuarios(self):
        self.limpar(); self.cabecalho("Usuários Cadastrados")
        frame = tk.Frame(self.root, bg=COR_FUNDO); frame.pack(fill="both", expand=True, padx=25, pady=20)
        tabela = self.montar_tabela(frame, ("id", "nome", "email", "tipo"), {"id":60,"nome":280,"email":360,"tipo":120})
        conn=conectar()
        for r in conn.execute("SELECT id_usuario,nome,email,tipo_usuario FROM usuarios ORDER BY id_usuario DESC"):
            tabela.insert("", "end", values=(r["id_usuario"], r["nome"], r["email"], r["tipo_usuario"]))
        conn.close(); BotaoAnimado(frame, "Voltar", self.tela_professor, cor=COR_CINZA).pack(pady=12)

    def tela_relatorios(self):
        self.limpar(); self.cabecalho("Relatórios de Desempenho")
        frame = tk.Frame(self.root, bg=COR_FUNDO); frame.pack(fill="both", expand=True, padx=25, pady=20)
        tabela = self.montar_tabela(
            frame,
            ("aluno", "pontos", "acertos", "erros", "total", "aproveitamento", "data"),
            {"aluno":260,"pontos":90,"acertos":90,"erros":90,"total":90,"aproveitamento":130,"data":180}
        )
        conn = conectar()
        for r in conn.execute("""
            SELECT
                u.nome,
                p.pontuacao_total,
                p.quantidade_acertos,
                p.quantidade_erros,
                p.total_perguntas,
                CASE
                    WHEN p.total_perguntas > 0 THEN ROUND((p.quantidade_acertos / p.total_perguntas) * 100, 1)
                    ELSE 0
                END AS aproveitamento,
                p.data_fim
            FROM partidas p
            JOIN usuarios u ON u.id_usuario=p.id_aluno
            WHERE p.status_partida='finalizada'
            ORDER BY p.data_fim DESC, p.id_partida DESC
        """):
            tabela.insert("", "end", values=(
                r["nome"],
                r["pontuacao_total"],
                r["quantidade_acertos"],
                r["quantidade_erros"],
                r["total_perguntas"],
                f"{r['aproveitamento']}%",
                r["data_fim"]
            ))
        conn.close()
        BotaoAnimado(frame, "Voltar", self.voltar_por_tipo, cor=COR_CINZA).pack(pady=12)

    def tela_ranking(self):
        if not self.usuario or self.usuario.get("tipo_usuario") != "professor":
            self.mostrar_mensagem("Acesso restrito", "O ranking geral está disponível apenas para professores.", "erro", self.tela_menu_aluno if self.usuario else self.tela_login)
            return
        self.limpar(); self.cabecalho("Ranking Geral")
        frame = tk.Frame(self.root, bg=COR_FUNDO); frame.pack(fill="both", expand=True, padx=25, pady=20)
        tabela = self.montar_tabela(
            frame,
            ("posição", "aluno", "melhor_pontuação", "acertos", "total", "aproveitamento", "data"),
            {"posição":90,"aluno":300,"melhor_pontuação":150,"acertos":90,"total":80,"aproveitamento":130,"data":170}
        )
        conn = conectar()
        ranking_sql = """
            SELECT
                u.nome,
                p.pontuacao_total AS melhor_pontuacao,
                p.quantidade_acertos AS melhor_acertos,
                p.total_perguntas,
                CASE
                    WHEN p.total_perguntas > 0 THEN ROUND((p.quantidade_acertos / p.total_perguntas) * 100, 1)
                    ELSE 0
                END AS aproveitamento,
                p.data_fim
            FROM partidas p
            JOIN usuarios u ON u.id_usuario=p.id_aluno
            WHERE p.status_partida='finalizada'
              AND NOT EXISTS (
                    SELECT 1
                    FROM partidas p2
                    WHERE p2.id_aluno = p.id_aluno
                      AND p2.status_partida='finalizada'
                      AND (
                          p2.pontuacao_total > p.pontuacao_total
                          OR (p2.pontuacao_total = p.pontuacao_total AND p2.quantidade_acertos > p.quantidade_acertos)
                          OR (p2.pontuacao_total = p.pontuacao_total AND p2.quantidade_acertos = p.quantidade_acertos AND p2.data_fim > p.data_fim)
                      )
              )
            ORDER BY p.pontuacao_total DESC, p.quantidade_acertos DESC, aproveitamento DESC, p.data_fim DESC
        """
        for pos, r in enumerate(conn.execute(ranking_sql), start=1):
            tabela.insert("", "end", values=(
                pos,
                r["nome"],
                r["melhor_pontuacao"],
                r["melhor_acertos"],
                r["total_perguntas"],
                f"{r['aproveitamento']}%",
                r["data_fim"]
            ))
        conn.close()
        BotaoAnimado(frame, "Voltar", self.voltar_por_tipo, cor=COR_CINZA).pack(pady=12)

    def voltar_por_tipo(self):
        if self.usuario and self.usuario.get("tipo_usuario") == "professor": self.tela_professor()
        elif self.usuario and self.usuario.get("tipo_usuario") == "aluno": self.tela_menu_aluno()
        else: self.tela_inicial()


if __name__ == "__main__":
    iniciar_banco()
    root = tk.Tk()
    app = JogoQuimica(root)
    root.mainloop()
